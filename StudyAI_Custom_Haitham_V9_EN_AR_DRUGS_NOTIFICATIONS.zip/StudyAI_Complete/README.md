# Study AI — Complete starter
هذا المشروع يحتوي على:
- Android Studio app (Kotlin + WebView) بواجهة Study AI.
- Backend FastAPI متصل بـ OpenAI Responses API.
- رفع PDF / DOCX / PPTX / صور.
- تحليل المادة.
- Chat مبني على المادة.
- واجهة RTL عربية + English.

## تشغيل Backend
1. Python 3.10+
2. داخل backend:
   pip install -r requirements.txt
3. انسخ .env.example إلى .env أو صدّر:
   OPENAI_API_KEY=...
4. شغّل:
   uvicorn main:app --host 0.0.0.0 --port 8000

## بناء APK
افتح مجلد android في Android Studio ثم Build > Build APK(s).
هذا المستودع يحتاج Android SDK/Gradle عبر Android Studio.

## مهم جداً
لا تضع OPENAI_API_KEY داخل APK أو JavaScript. مفتاح API يجب أن يبقى على الخادم، لأن مفاتيح OpenAI سرية ولا ينبغي كشفها في تطبيقات العميل. راجع توثيق OpenAI الرسمي.


## Build fix
The Android module is configured with Java 17 and Kotlin JVM target 17 so Gradle's JVM-target validation passes.


## V9 updates
- English-first material rewriting, with on-demand Arabic medical translation.
- Improved pharmacy/drug section with AI drug-card lookup.
- Safer large-file processing and full extracted-text retention.
- Android completion notification after AI analysis.
- Pharmacy-branded launcher icon and safer phone edge/safe-area layout.
- App version 2.2.0.
