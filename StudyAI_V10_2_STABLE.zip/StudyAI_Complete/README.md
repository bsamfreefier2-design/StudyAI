# Study AI V10

Single universal Android APK for Study AI with server-side device activation.

## Licensing
- Every installation gets an Android Device ID from `Settings.Secure.ANDROID_ID`.
- AI endpoints require `X-Device-ID` and an active license on the backend.
- Developer activation is performed from `/admin` using `STUDYAI_ADMIN_KEY`.
- `/admin/activate`, `/admin/revoke`, and `/admin/licenses` are protected by the admin key.
- Keep `STUDYAI_ADMIN_KEY` only in the Render environment; never put it in the APK.

## Important production note
The default license store is SQLite. On Render, use a persistent storage/database before selling licenses so activations survive redeployments. If the service has no persistent disk, the SQLite file may be lost on redeploy.

## AI limits
V10 reduces token bursts by chunking feature requests and lowering output sizes. It cannot bypass OpenAI account usage/rate limits or make API usage free.
