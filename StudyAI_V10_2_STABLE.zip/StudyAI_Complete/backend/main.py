import os
import base64
import io
import json
import re
import time
import sqlite3
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI

try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None
try:
    from docx import Document
except Exception:
    Document = None
try:
    from pptx import Presentation
except Exception:
    Presentation = None

app = FastAPI(title="Study AI Backend", version="4.0")

origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins or ["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

API_KEY = os.getenv("OPENAI_API_KEY")
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")
client = OpenAI(api_key=API_KEY) if API_KEY else None

# Large-file protection: keep each AI request comfortably below the TPM limit.
CHUNK_CHARS = int(os.getenv("AI_CHUNK_CHARS", "12000"))
LARGE_FILE_CHARS = int(os.getenv("AI_LARGE_FILE_CHARS", "36000"))
MAX_RETRIES = 0


# Device activation / licensing
ADMIN_KEY = os.getenv("STUDYAI_ADMIN_KEY", "")
LICENSE_DB_PATH = os.getenv("LICENSE_DB_PATH", "/data/studyai_licenses.db")


def _license_db():
    path = Path(LICENSE_DB_PATH)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        path = Path("/tmp/studyai_licenses.db")
    con = sqlite3.connect(str(path), timeout=10)
    con.execute("""
        CREATE TABLE IF NOT EXISTS licenses (
            device_id TEXT PRIMARY KEY,
            customer TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            expires_at TEXT DEFAULT NULL
        )
    """)
    con.commit()
    return con


def _is_active(device_id: str) -> bool:
    if not device_id:
        return False
    con = _license_db()
    try:
        row = con.execute(
            "SELECT status, expires_at FROM licenses WHERE device_id=?",
            (device_id,)
        ).fetchone()
        if not row or row[0] != "active":
            return False
        if row[1]:
            from datetime import datetime, timezone
            try:
                exp = datetime.fromisoformat(row[1].replace("Z", "+00:00"))
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if exp <= datetime.now(timezone.utc):
                    return False
            except Exception:
                pass
        return True
    finally:
        con.close()


def require_activation(request: Request):
    device_id = (request.headers.get("X-Device-ID") or "").strip()
    if not _is_active(device_id):
        raise HTTPException(
            403,
            "هذا الجهاز غير مفعّل. أرسل Device ID إلى مطوّر Study AI للحصول على التفعيل."
        )
    return device_id


def require_admin(request: Request):
    if not ADMIN_KEY:
        raise HTTPException(503, "STUDYAI_ADMIN_KEY غير مضبوط على الخادم.")
    if request.headers.get("X-Admin-Key") != ADMIN_KEY:
        raise HTTPException(401, "مفتاح المطوّر غير صحيح.")


# Prototype storage for one user's latest uploaded material.
# For a multi-user production service, replace this with per-user/session storage.
last_material = {
    "name": None,
    "text": "",
    "image_data": None,
    "mime": None,
}

SYSTEM = """You are Study AI, an academic study assistant specialized in medical and pharmaceutical education.

Core rules:
- Use the uploaded study material as the primary source.
- Do not invent scientific facts, doses, drug names, numbers, units, abbreviations, or exam certainty.
- If the material is unclear or missing the answer, say so.
- If you add knowledge not present in the material, label it exactly as: "معلومة إضافية".
- For Arabic translation, use accurate medical/pharmaceutical terminology and keep the English term beside it when useful.
- Keep the material's meaning; do not silently omit important information.
- Prefer clear Arabic RTL-friendly headings and concise bullets.
- Never claim that a question is guaranteed to appear on an exam. Use "High-Yield" or "مرجّح للمراجعة".
"""

def require_client():
    if not client:
        raise HTTPException(503, "OPENAI_API_KEY غير مضبوط على الخادم.")

def extract_text(data: bytes, name: str) -> str:
    ext = Path(name).suffix.lower()
    if ext == ".pdf" and PdfReader:
        reader = PdfReader(io.BytesIO(data))
        return "\n\n".join((page.extract_text() or "") for page in reader.pages)
    if ext == ".docx" and Document:
        doc = Document(io.BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    if ext == ".pptx" and Presentation:
        prs = Presentation(io.BytesIO(data))
        parts = []
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    parts.append(shape.text)
        return "\n".join(parts)
    if ext in [".txt", ".md"]:
        return data.decode("utf-8", errors="replace")
    return ""

def clean_json(raw: str):
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
        raw = re.sub(r"\s*```$", "", raw)
    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        raw = raw[start:end + 1]
    return json.loads(raw)

def make_input(instruction: str):
    if last_material["image_data"]:
        return [{
            "role": "user",
            "content": [
                {"type": "input_text", "text": instruction},
                {
                    "type": "input_image",
                    "image_url": f"data:{last_material['mime']};base64,{last_material['image_data']}",
                },
            ],
        }]
    return instruction + "\n\nSTUDY MATERIAL:\n" + last_material["text"]

def _responses_create(**kwargs):
    """Make one AI request. Do not blindly retry 429s: failed requests consume rate-limit budget too."""
    require_client()
    try:
        return client.responses.create(**kwargs)
    except Exception:
        raise

def ask_ai(instruction: str, text_override: str | None = None, schema=None, name="study_analysis", max_output_tokens=2500) -> str:
    require_client()
    if text_override is None:
        input_value = make_input(instruction)
    else:
        input_value = instruction + "\n\nSTUDY MATERIAL EXCERPT:\n" + text_override
    kwargs = {
        "model": MODEL,
        "instructions": SYSTEM,
        "input": input_value,
        "max_output_tokens": max_output_tokens,
    }
    if schema is not None:
        kwargs["text"] = {"format": {"type": "json_schema", "name": name, "strict": True, "schema": schema}}
    response = _responses_create(**kwargs)
    return response.output_text.strip()

@app.get("/health")
def health():
    return {"ok": True, "model": MODEL, "material_loaded": bool(last_material["name"])}

@app.get("/license/status")
def license_status(device_id: str = ""):
    return {"active": _is_active(device_id.strip()), "device_id": device_id.strip()}


@app.get("/admin", response_class=HTMLResponse)
def admin_page():
    return HTMLResponse("""
<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Study AI Admin</title>
<style>body{font-family:Arial,Tahoma,sans-serif;background:#f3f7fb;margin:0;padding:20px;color:#172033}.box{max-width:720px;margin:auto;background:#fff;border-radius:18px;padding:20px;box-shadow:0 8px 30px #0001}input,button{width:100%;box-sizing:border-box;padding:13px;margin:6px 0;border-radius:10px;border:1px solid #ccd8e4}button{background:#167fc1;color:#fff;border:0;font-weight:700;cursor:pointer}.danger{background:#b42318}.muted{color:#64748b}.row{display:grid;grid-template-columns:1fr 1fr;gap:8px}@media(max-width:600px){.row{grid-template-columns:1fr}}pre{white-space:pre-wrap;word-break:break-word;background:#f5f8fb;padding:12px;border-radius:10px}</style></head>
<body><div class="box"><h1>🛠️ Study AI — لوحة المطوّر</h1><p class="muted">تفعيل أو إلغاء تفعيل جهاز. لا تشارك مفتاح المطوّر.</p>
<input id="key" type="password" placeholder="Developer Key"><input id="device" placeholder="Device ID"><input id="customer" placeholder="اسم العميل (اختياري)"><input id="expires" placeholder="انتهاء الترخيص ISO مثل 2027-09-16T00:00:00+00:00"><div class="row"><button onclick="act('/admin/activate')">✅ تفعيل</button><button class="danger" onclick="act('/admin/revoke')">🚫 إلغاء التفعيل</button></div><button onclick="listAll()">📋 عرض التفعيلات</button><pre id="out">جاهز.</pre></div>
<script>const h=()=>({'Content-Type':'application/json','X-Admin-Key':document.getElementById('key').value});async function act(url){const body={device_id:document.getElementById('device').value.trim(),customer:document.getElementById('customer').value.trim(),expires_at:document.getElementById('expires').value.trim()||null};const r=await fetch(url,{method:'POST',headers:h(),body:JSON.stringify(body)});document.getElementById('out').textContent=await r.text()}async function listAll(){const r=await fetch('/admin/licenses',{headers:{'X-Admin-Key':document.getElementById('key').value}});document.getElementById('out').textContent=await r.text()}</script></body></html>
""")

class LicenseRequest(BaseModel):
    device_id: str
    customer: str = ""
    expires_at: str | None = None


@app.post("/admin/activate")
def admin_activate(body: LicenseRequest, request: Request):
    require_admin(request)
    device_id = body.device_id.strip()
    if not device_id:
        raise HTTPException(400, "Device ID مطلوب.")
    con = _license_db()
    try:
        con.execute(
            "INSERT INTO licenses(device_id,customer,status,expires_at) VALUES(?,?,?,?) "
            "ON CONFLICT(device_id) DO UPDATE SET customer=excluded.customer,status='active',expires_at=excluded.expires_at",
            (device_id, body.customer.strip(), "active", body.expires_at),
        )
        con.commit()
    finally:
        con.close()
    return {"ok": True, "device_id": device_id, "status": "active", "expires_at": body.expires_at}


@app.post("/admin/revoke")
def admin_revoke(body: LicenseRequest, request: Request):
    require_admin(request)
    device_id = body.device_id.strip()
    con = _license_db()
    try:
        con.execute("UPDATE licenses SET status='revoked' WHERE device_id=?", (device_id,))
        con.commit()
    finally:
        con.close()
    return {"ok": True, "device_id": device_id, "status": "revoked"}


@app.get("/admin/licenses")
def admin_licenses(request: Request):
    require_admin(request)
    con = _license_db()
    try:
        rows = con.execute("SELECT device_id,customer,status,created_at,expires_at FROM licenses ORDER BY created_at DESC").fetchall()
    finally:
        con.close()
    return {"licenses": [dict(zip(["device_id","customer","status","created_at","expires_at"], r)) for r in rows]}


@app.post("/analyze")
async def analyze(request: Request, file: UploadFile = File(...)):
    require_activation(request)

    data = await file.read()
    mime = file.content_type or ""
    text = extract_text(data, file.filename)

    if not text and not mime.startswith("image/"):
        raise HTTPException(
            400,
            "لم أستطع استخراج النص من هذا الملف. استخدم PDF/DOCX/PPTX أو صورة واضحة."
        )

    last_material["name"] = file.filename
    last_material["text"] = text
    last_material["mime"] = mime
    last_material["image_data"] = (
        base64.b64encode(data).decode("ascii") if mime.startswith("image/") else None
    )

    prompt = """حلّل المادة الدراسية تحليلاً شاملاً، ثم أعد النتيجة كـ JSON صالح فقط، بدون Markdown وبدون أي نص خارج JSON.
استخدم هذه المفاتيح حرفياً:
{
  "title": "اسم المادة أو الموضوع",
  "summary": "ملخص واضح",
  "difficulty": "سهل/متوسط/صعب",
  "understanding": 0,
  "high_yield": ["نقاط High-Yield"],
  "topics": ["المواضيع الرئيسية"],
  "must_memorize": ["ما يجب حفظه"],
  "must_understand": ["ما يجب فهمه"],
  "terms": [{"english":"", "arabic":"", "explanation":""}],
  "comparisons": ["مقارنات مهمة"],
  "rewrite": "A clear, organized English rewrite of the study material, preserving the original scientific meaning and important terminology.",
  "study_plan": ["خطوات مرتبة لدراسة المادة"],
  "quick_revision": ["نقاط مراجعة سريعة"],
  "questions": [{"question":"", "options":["A) ","B) ","C) ","D) "], "answer":"", "explanation":""}],
  "flashcards": [{"front":"", "back":""}]
}
اجعل understanding رقماً من 0 إلى 100 يمثل وضوح المادة واستيعاب بنيتها، وليس تشخيصاً لمستوى الطالب.
لا تضع معلومات غير موجودة في المادة إلا إذا وسمتها داخل النص بأنها "معلومة إضافية".
"""

    full_schema = {
        "type": "object", "additionalProperties": False,
        "properties": {
            "title": {"type": "string"}, "summary": {"type": "string"}, "difficulty": {"type": "string"},
            "understanding": {"type": "integer", "minimum": 0, "maximum": 100},
            "high_yield": {"type": "array", "items": {"type": "string"}},
            "topics": {"type": "array", "items": {"type": "string"}},
            "must_memorize": {"type": "array", "items": {"type": "string"}},
            "must_understand": {"type": "array", "items": {"type": "string"}},
            "terms": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"english": {"type": "string"}, "arabic": {"type": "string"}, "explanation": {"type": "string"}}, "required": ["english", "arabic", "explanation"]}},
            "comparisons": {"type": "array", "items": {"type": "string"}}, "rewrite": {"type": "string"},
            "study_plan": {"type": "array", "items": {"type": "string"}}, "quick_revision": {"type": "array", "items": {"type": "string"}},
            "questions": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"question": {"type": "string"}, "options": {"type": "array", "items": {"type": "string"}}, "answer": {"type": "string"}, "explanation": {"type": "string"}}, "required": ["question", "options", "answer", "explanation"]}},
            "flashcards": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"front": {"type": "string"}, "back": {"type": "string"}}, "required": ["front", "back"]}}
        },
        "required": ["title", "summary", "difficulty", "understanding", "high_yield", "topics", "must_memorize", "must_understand", "terms", "comparisons", "rewrite", "study_plan", "quick_revision", "questions", "flashcards"]
    }

    chunk_schema = {
        "type": "object", "additionalProperties": False,
        "properties": {
            "title": {"type": "string"}, "summary": {"type": "string"},
            "high_yield": {"type": "array", "items": {"type": "string"}},
            "topics": {"type": "array", "items": {"type": "string"}},
            "must_memorize": {"type": "array", "items": {"type": "string"}},
            "must_understand": {"type": "array", "items": {"type": "string"}},
            "terms": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"english": {"type": "string"}, "arabic": {"type": "string"}, "explanation": {"type": "string"}}, "required": ["english", "arabic", "explanation"]}},
            "comparisons": {"type": "array", "items": {"type": "string"}}
        },
        "required": ["title", "summary", "high_yield", "topics", "must_memorize", "must_understand", "terms", "comparisons"]
    }

    # Small/medium files: one request, with a hard input cap that stays below the rate limit.
    if len(text) <= LARGE_FILE_CHARS:
        try:
            raw = ask_ai(prompt, text_override=text[:LARGE_FILE_CHARS], schema=full_schema, name="study_analysis", max_output_tokens=3200)
            result = json.loads(raw)
            return {"filename": file.filename, "model": MODEL, "analysis": result}
        except Exception as exc:
            if "rate_limit" in str(exc).lower() or "429" in str(exc):
                raise HTTPException(429, "الذكاء الاصطناعي مشغول حالياً بسبب حد التوكنات (429). انتظر حتى يخف الحد ثم جرّب ملفاً أصغر.")
            raise HTTPException(502, f"فشل تحليل المادة: {exc}")

    # Large files: analyze sequential chunks, then synthesize the compact chunk results.
    chunks = []
    pos = 0
    while pos < len(text):
        end = min(len(text), pos + CHUNK_CHARS)
        chunks.append(text[pos:end])
        if end >= len(text):
            break
        pos = max(end - 1200, pos + 1)  # small overlap keeps definitions across boundaries

    partials = []
    for i, chunk in enumerate(chunks, 1):
        instruction = f"حلّل الجزء {i} من {len(chunks)} من المادة فقط. استخرج المعلومات المهمة الموجودة فعلياً في هذا الجزء، ولا تخترع معلومات. كن مختصراً لأن هذه نتيجة وسيطة ستُدمج لاحقاً."
        try:
            raw = ask_ai(instruction, text_override=chunk, schema=chunk_schema, name="study_chunk", max_output_tokens=1500)
            partials.append(json.loads(raw))
        except Exception as exc:
            if "rate_limit" in str(exc).lower() or "429" in str(exc):
                raise HTTPException(429, "الملف كبير على حد التوكنات الحالي. جرّب ملفاً أصغر أو قسّم المادة.")
            raise HTTPException(502, f"فشل تحليل الجزء {i}: {exc}")
        time.sleep(1.2)

    combined = json.dumps(partials, ensure_ascii=False)
    final_instruction = """ادمج نتائج تحليل أجزاء المادة التالية في تحليل نهائي واحد. لا تضف معلومات غير موجودة في نتائج الأجزاء. احذف التكرار، وحافظ على أهم النقاط والمصطلحات، ثم أنشئ النتيجة الكاملة بالمخطط المطلوب.\n\nنتائج الأجزاء:\n""" + combined
    try:
        raw = ask_ai(final_instruction, text_override="", schema=full_schema, name="study_analysis", max_output_tokens=2400)
        result = json.loads(raw)
    except Exception as exc:
        if "rate_limit" in str(exc).lower() or "429" in str(exc):
            raise HTTPException(429, "تم الوصول إلى حد التوكنات أثناء تجميع التحليل. جرّب لاحقاً أو استخدم مادة أصغر.")
        raise HTTPException(502, f"فشل تجميع التحليل: {exc}")

    return {"filename": file.filename, "model": MODEL, "analysis": result}



def ask_feature(instruction: str, max_output_tokens: int = 1600) -> str:
    """Run feature requests with bounded context to reduce TPM bursts."""
    text = last_material.get("text", "")
    if not text:
        return ask_ai(instruction, max_output_tokens=max_output_tokens)

    # Rewrite/translation can be assembled from smaller sections.
    if len(text) <= 18000:
        return ask_ai(instruction, text_override=text, max_output_tokens=max_output_tokens)

    parts = []
    step = 12000
    overlap = 600
    pos = 0
    while pos < len(text):
        end = min(len(text), pos + step)
        chunk = text[pos:end]
        parts.append(ask_ai(
            instruction + f"\n\nهذا الجزء {len(parts)+1} من المادة. عالج هذا الجزء فقط وحافظ على المصطلحات المهمة.",
            text_override=chunk,
            max_output_tokens=max_output_tokens,
        ))
        if end >= len(text):
            break
        pos = max(end - overlap, pos + 1)
        time.sleep(0.8)

    return "\n\n---\n\n".join(parts)

FEATURE_PROMPTS = {
    "rewrite": """Rewrite the uploaded study material in clear professional ENGLISH as an organized study handout. Keep the scientific meaning, important details, headings, definitions, mechanisms, numbers, units, and medical/pharmaceutical terminology. Do not translate it to Arabic in this mode. Do not invent information.""",
    "translate_ar": """Translate the uploaded study material into accurate medical/pharmaceutical ARABIC. Keep the original English term beside the Arabic translation when useful. Preserve headings, definitions, mechanisms, numbers, units, and important details. Do not invent information.""",
    "study": """أنشئ خطة دراسة عملية لهذه المادة: ترتيب المواضيع، ماذا أحفظ، ماذا أفهم، ثم أسئلة ومراجعة. اجعلها مناسبة لطالب طب/صيدلة.""",
    "questions": """أنشئ أسئلة امتحانية من المادة، متنوعة بين MCQ وأسئلة فهم. اذكر الإجابة الصحيحة وسببها. لا تدّعِ أن أي سؤال مضمون في الامتحان.""",
    "flashcards": """أنشئ Flashcards تغطي التعاريف والمصطلحات والآليات والأرقام والمقارنات المهمة في المادة. كل بطاقة سؤال/مصطلح ثم جواب مختصر.""",
    "terms": """استخرج أهم المصطلحات الطبية والصيدلانية من المادة في جدول نصي: English | العربية | شرح مبسط.""",
    "revision": """أنشئ مراجعة سريعة جداً للمادة: أهم ما يجب حفظه، أهم ما يجب فهمه، الأخطاء الشائعة، ونقاط High-Yield.""",
    "progress": """قيّم بنية المادة وصعوبتها ووضوحها، ثم أعطِ خطة لتحسين الدراسة. لا تدّعي معرفة مستوى الطالب الحقيقي دون بيانات اختبار.""",
    "drug": """اعمل بطاقة تعليمية عن الدواء أو المادة الفعالة المذكورة في السؤال اعتماداً على المادة المرفوعة أولاً. اذكر: الاسم العلمي، الفئة الدوائية، آلية العمل إذا كانت موجودة، الاستعمالات العامة المذكورة، الأشكال الصيدلانية/التراكيز إن وردت، أهم التحذيرات أو الآثار الجانبية إن وردت. لا تعطِ جرعة شخصية أو وصفة علاجية. إذا لم تكن المعلومة في الملف فقل ذلك بوضوح، وأي معرفة إضافية ابدأها بعبارة "معلومة إضافية".""",
}


class FeatureRequest(BaseModel):
    feature: str
    query: str = ""

@app.post("/feature")
def feature(body: FeatureRequest, request: Request):
    require_activation(request)
    if not last_material["name"]:
        raise HTTPException(400, "ارفع المادة أولاً.")
    instruction = FEATURE_PROMPTS.get(body.feature)
    if not instruction:
        raise HTTPException(400, "الميزة غير معروفة.")
    if body.feature == "drug":
        if not body.query.strip():
            raise HTTPException(400, "اكتب اسم الدواء أو المادة الفعالة.")
        instruction += "\n\nاسم الدواء/المادة الفعالة المطلوب تحليلها: " + body.query.strip()
    return {"feature": body.feature, "answer": ask_feature(instruction)}

class ChatRequest(BaseModel):
    question: str

@app.post("/chat")
def chat(body: ChatRequest, request: Request):
    require_activation(request)
    if not last_material["name"]:
        return {"answer": "ارفع مادة أولاً حتى أجيب بناءً عليها."}
    q = body.question.strip()
    if not q:
        raise HTTPException(400, "اكتب السؤال.")
    instruction = f"""أجب عن سؤال الطالب اعتماداً على المادة المرفوعة أولاً.
إذا لم تكن الإجابة موجودة في المادة، قل ذلك بوضوح. وإذا استخدمت معرفة إضافية، ابدأ فقرتها بـ "معلومة إضافية".

سؤال الطالب:
{q}
"""
    return {"answer": ask_feature(instruction, max_output_tokens=900)}

@app.post("/reset")
def reset():
    last_material.update({"name": None, "text": "", "image_data": None, "mime": None})
    return {"ok": True}
