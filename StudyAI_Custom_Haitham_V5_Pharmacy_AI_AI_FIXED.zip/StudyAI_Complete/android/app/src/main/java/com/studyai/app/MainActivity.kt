package com.studyai.app

import android.app.Activity
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.webkit.*
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.graphics.Color
import androidx.core.content.FileProvider
import java.io.File

class MainActivity : Activity() {
    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private val PICK_FILE = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        val web = WebView(this)
        val splash = ImageView(this).apply {
            setImageResource(R.drawable.studyai_splash)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.WHITE)
            contentDescription = "Study AI"
        }

        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = false

        web.addJavascriptInterface(object {
            @JavascriptInterface
            fun shareText(text: String) {
                runOnUiThread {
                    try {
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        startActivity(Intent.createChooser(share, "مشاركة Study AI"))
                    } catch (e: Exception) { }
                }
            }

            @JavascriptInterface
            fun openInstagram() {
                runOnUiThread {
                    try {
                        val appUri = Uri.parse("instagram://user?username=g.9.g.g")
                        startActivity(Intent(Intent.ACTION_VIEW, appUri))
                    } catch (e: Exception) {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/g.9.g.g")))
                    }
                }
            }

            @JavascriptInterface
            fun shareApp() {
                runOnUiThread {
                    try {
                        val apkFile = File(cacheDir, "StudyAI-${BuildConfig.EDITION}.apk")
                        File(applicationInfo.sourceDir).copyTo(apkFile, overwrite = true)
                        val uri = FileProvider.getUriForFile(
                            this@MainActivity,
                            "${BuildConfig.APPLICATION_ID}.fileprovider",
                            apkFile
                        )
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "application/vnd.android.package-archive"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(share, "إرسال نسخة Study AI"))
                    } catch (e: Exception) {
                        // Keep the app usable if the device blocks APK sharing.
                    }
                }
            }
        }, "Android")

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                uploadCallback?.onReceiveValue(null)
                uploadCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
                intent.addCategory(Intent.CATEGORY_OPENABLE)
                intent.type = "*/*"
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                startActivityForResult(intent, PICK_FILE)
                return true
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(
                    "window.APP_MODE='${BuildConfig.EDITION}'; window.APP_VERSION='${BuildConfig.VERSION_NAME}'; if(window.initApp) window.initApp();",
                    null
                )
            }
        }

        val mode = BuildConfig.EDITION
        web.loadUrl("file:///android_asset/index.html?mode=$mode")

        Handler(Looper.getMainLooper()).postDelayed({
            splash.animate().alpha(0f).setDuration(350).withEndAction {
                root.removeView(splash)
            }.start()
        }, 1500)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE) {
            val result = if (resultCode == RESULT_OK && data?.data != null)
                arrayOf(data.data!!)
            else null
            uploadCallback?.onReceiveValue(result)
            uploadCallback = null
        }
    }
}
