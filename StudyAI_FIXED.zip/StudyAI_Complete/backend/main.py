import os, base64, io, json
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI

try:
    from pypdf import PdfReader
except Exception: PdfReader = None
try:
    from docx import Document
except Exception: Document = None
try:
    from pptx import Presentation
except Exception: Presentation = None

app = FastAPI(title="Study AI Backend")
origins = os.getenv("ALLOWED_ORIGINS","*").split(",")
app.add_middleware(CORSMiddleware, allow_origins=origins, allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
MODEL = os.getenv("OPENAI_MODEL","gpt-5.6-luna")
last_material = {"name": None, "text": ""}

SYSTEM = """You are Study AI, an academic study assistant specialized in medical and pharmaceutical education.
Rules:
- Base answers primarily on the uploaded material.
- Never invent scientific facts, doses, drug names, numbers, units, or abbreviations.
- If the material is unclear, explicitly say it is unclear.
- If adding external knowledge, label it 'معلومة إضافية'.
- For translation, use accurate medical/pharmaceutical terminology and preserve English terms when useful.
- Never claim an exam question is certain; say it is likely/high-yield.
- Produce concise, structured Arabic with English terms where appropriate.
"""

def extract_text(data: bytes, name: str) -> str:
    ext = Path(name).suffix.lower()
    if ext == ".pdf" and PdfReader:
        r = PdfReader(io.BytesIO(data))
        return "\n\n".join((p.extract_text() or "") for p in r.pages)
    if ext in [".docx"] and Document:
        d = Document(io.BytesIO(data))
        return "\n".join(p.text for p in d.paragraphs)
    if ext in [".pptx"] and Presentation:
        prs = Presentation(io.BytesIO(data))
        out=[]
        for s in prs.slides:
            for sh in s.shapes:
                if hasattr(sh,"text"): out.append(sh.text)
        return "\n".join(out)
    return ""

def ask_ai(prompt: str) -> str:
    r = client.responses.create(model=MODEL, instructions=SYSTEM, input=prompt)
    return r.output_text

@app.get("/health")
def health(): return {"ok": True, "model": MODEL}

@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    global last_material
    data = await file.read()
    text = extract_text(data, file.filename)
    if not text and file.content_type and file.content_type.startswith("image/"):
        b64=base64.b64encode(data).decode()
        prompt=[{"role":"user","content":[
            {"type":"input_text","text":"حلل هذه الصورة كمذكرة دراسية. استخرج النص، ثم أنشئ: اسم المادة/الموضوع، أهم المواضيع، أهم النقاط، مصطلحات طبية، ما يجب حفظه وما يجب فهمه، وأولوية الدراسة."},
            {"type":"input_image","image_url":f"data:{file.content_type};base64,{b64}"}
        ]}]
        r=client.responses.create(model=MODEL,instructions=SYSTEM,input=prompt)
        answer=r.output_text
    else:
        if not text: raise HTTPException(400,"صيغة الملف غير مدعومة أو لم يمكن استخراج النص.")
        last_material={"name":file.filename,"text":text[:200000]}
        prompt=f"""حلل الملف الدراسي التالي تحليلاً شاملاً.
أعد النتيجة بعناوين: اسم/موضوع المادة، خريطة المادة، المواضيع الرئيسية، مستوى الصعوبة، أهم النقاط، High-Yield، ما يجب حفظه، ما يجب فهمه، مصطلحات طبية، مقارنات، وخطة دراسة منطقية.
لا تحذف المعلومات المهمة ولا تدّعِ اليقين بشأن الامتحان.

FILE:
{text[:200000]}"""
        answer=ask_ai(prompt)
    return {"filename":file.filename,"summary":answer}

class Chat(BaseModel):
    question: str

@app.post("/chat")
def chat(body: Chat):
    context=last_material.get("text","")
    if not context:
        return {"answer":"ارفع ملف المادة أولاً حتى تكون الإجابة مبنية عليه."}
    prompt=f"""أجب عن سؤال الطالب اعتماداً على المادة المرفوعة أدناه.
إذا لم تجد الإجابة في المادة، قل ذلك بوضوح. إذا أضفت معرفة خارجية، ضع 'معلومة إضافية'.

سؤال الطالب:
{body.question}

المادة:
{context[:180000]}"""
    return {"answer":ask_ai(prompt)}
