import os
import base64
import io
import json
import re
import time
import sqlite3
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI

try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None
try:
    from docx import Document
except Exception:
    Document = None
try:
    from pptx import Presentation
except Exception:
    Presentation = None

app = FastAPI(title="Study AI Backend", version="4.0")

origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins or ["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

API_KEY = os.getenv("OPENAI_API_KEY")
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")
client = OpenAI(api_key=API_KEY) if API_KEY else None

# Large-file protection: keep each AI request comfortably below the TPM limit.
CHUNK_CHARS = int(os.getenv("AI_CHUNK_CHARS", "8000"))
LARGE_FILE_CHARS = int(os.getenv("AI_LARGE_FILE_CHARS", "16000"))
MAX_RETRIES = 0


# Device activation / licensing
ADMIN_KEY = os.getenv("STUDYAI_ADMIN_KEY", "")
LICENSE_DB_PATH = os.getenv("LICENSE_DB_PATH", "/data/studyai_licenses.db")


def _license_db():
    path = Path(LICENSE_DB_PATH)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        path = Path("/tmp/studyai_licenses.db")
    con = sqlite3.connect(str(path), timeout=10)
    con.execute("""
        CREATE TABLE IF NOT EXISTS licenses (
            device_id TEXT PRIMARY KEY,
            customer TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            expires_at TEXT DEFAULT NULL,
            started_at TEXT DEFAULT NULL,
            duration_days INTEGER DEFAULT 30,
            ai_quota INTEGER DEFAULT 100000,
            ai_used INTEGER DEFAULT 0,
            last_used_at TEXT DEFAULT NULL
        )
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS license_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    con.commit()

    # Upgrade databases created by older versions.
    for col, typ in [("started_at","TEXT"),("duration_days","INTEGER DEFAULT 30"),("ai_quota","INTEGER DEFAULT 100000"),("ai_used","INTEGER DEFAULT 0"),("last_used_at","TEXT DEFAULT NULL")]:
        try: con.execute(f"ALTER TABLE licenses ADD COLUMN {col} {typ}")
        except sqlite3.OperationalError: pass
    con.commit()
    return con


def _is_active(device_id: str) -> bool:
    if not device_id:
        return False
    con = _license_db()
    try:
        row = con.execute(
            "SELECT status, expires_at FROM licenses WHERE device_id=?",
            (device_id,)
        ).fetchone()
        if not row or row[0] != "active":
            return False
        if row[1]:
            from datetime import datetime, timezone
            try:
                exp = datetime.fromisoformat(row[1].replace("Z", "+00:00"))
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if exp <= datetime.now(timezone.utc):
                    return False
            except Exception:
                pass
        return True
    finally:
        con.close()


def _is_expired(expires_at: str):
    from datetime import datetime, timezone
    try:
        exp=datetime.fromisoformat(expires_at.replace("Z","+00:00"))
        if exp.tzinfo is None: exp=exp.replace(tzinfo=timezone.utc)
        return exp <= datetime.now(timezone.utc)
    except Exception: return False

def _duration_expiry(days: int):
    from datetime import datetime, timedelta, timezone
    return (datetime.now(timezone.utc)+timedelta(days=days)).isoformat()

def _log_history(con, device_id: str, action: str, details: str = ""):
    con.execute(
        "INSERT INTO license_history(device_id,action,details) VALUES(?,?,?)",
        (device_id, action, details)
    )

def _consume_ai(device_id: str, estimated_tokens: int):
    con=_license_db()
    try:
        row=con.execute("SELECT ai_quota,ai_used,status,expires_at FROM licenses WHERE device_id=?",(device_id,)).fetchone()
        if not row or row[2] != "active": raise HTTPException(403,"الترخيص غير فعال.")
        quota,used,status,expires=row
        if expires and _is_expired(expires): raise HTTPException(403,"انتهى الاشتراك. تواصل مع المطور للتجديد.")
        estimated_tokens=max(0,int(estimated_tokens))
        if quota and used+estimated_tokens>quota:
            raise HTTPException(429,"انتهت حصة الذكاء الاصطناعي لهذا الاشتراك. تواصل مع المطور لتجديد الحصة.")
        con.execute("UPDATE licenses SET ai_used=ai_used+?,last_used_at=CURRENT_TIMESTAMP WHERE device_id=?",(estimated_tokens,device_id)); con.commit()
    finally: con.close()

def require_activation(request: Request):
    device_id = (request.headers.get("X-Device-ID") or "").strip()
    if not _is_active(device_id):
        raise HTTPException(
            403,
            "هذا الجهاز غير مفعّل. أرسل Device ID إلى مطوّر Study AI للحصول على التفعيل."
        )
    return device_id


def require_admin(request: Request):
    if not ADMIN_KEY:
        raise HTTPException(503, "STUDYAI_ADMIN_KEY غير مضبوط على الخادم.")
    if request.headers.get("X-Admin-Key") != ADMIN_KEY:
        raise HTTPException(401, "مفتاح المطوّر غير صحيح.")


# Prototype storage for one user's latest uploaded material.
# For a multi-user production service, replace this with per-user/session storage.
last_material = {
    "name": None,
    "text": "",
    "image_data": None,
    "mime": None,
}

SYSTEM = """You are Study AI, an academic study assistant specialized in medical and pharmaceutical education.

Core rules:
- If a study material is explicitly provided for the current request, use it as the primary source.
- If no material is provided, answer the user normally using your general knowledge, while keeping medical/pharmaceutical answers educational and careful.
- Do not invent scientific facts, doses, drug names, numbers, units, abbreviations, or exam certainty.
- If the material is unclear or missing the answer, say so.
- If you add knowledge not present in the material, label it exactly as: "معلومة إضافية".
- For Arabic translation, use accurate medical/pharmaceutical terminology and keep the English term beside it when useful.
- Keep the material's meaning; do not silently omit important information.
- Prefer clear Arabic RTL-friendly headings and concise bullets.
- Never claim that a question is guaranteed to appear on an exam. Use "High-Yield" or "مرجّح للمراجعة".
"""

def require_client():
    if not client:
        raise HTTPException(503, "OPENAI_API_KEY غير مضبوط على الخادم.")

def extract_text(data: bytes, name: str) -> str:
    ext = Path(name).suffix.lower()
    if ext == ".pdf" and PdfReader:
        reader = PdfReader(io.BytesIO(data))
        return "\n\n".join((page.extract_text() or "") for page in reader.pages)
    if ext == ".docx" and Document:
        doc = Document(io.BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    if ext == ".pptx" and Presentation:
        prs = Presentation(io.BytesIO(data))
        parts = []
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    parts.append(shape.text)
        return "\n".join(parts)
    if ext in [".txt", ".md"]:
        return data.decode("utf-8", errors="replace")
    return ""

def clean_json(raw: str):
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
        raw = re.sub(r"\s*```$", "", raw)
    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        raw = raw[start:end + 1]
    return json.loads(raw)

def make_input(instruction: str):
    if last_material["image_data"]:
        return [{
            "role": "user",
            "content": [
                {"type": "input_text", "text": instruction},
                {
                    "type": "input_image",
                    "image_url": f"data:{last_material['mime']};base64,{last_material['image_data']}",
                },
            ],
        }]
    return instruction + "\n\nSTUDY MATERIAL:\n" + last_material["text"]

def _responses_create(**kwargs):
    require_client()
    return client.responses.create(**kwargs)

def ask_ai(instruction: str, text_override: str | None = None, schema=None, name="study_analysis", max_output_tokens=2500) -> str:
    require_client()
    if text_override is None:
        input_value = make_input(instruction)
    else:
        input_value = instruction + "\n\nSTUDY MATERIAL EXCERPT:\n" + text_override
    kwargs = {
        "model": MODEL,
        "instructions": SYSTEM,
        "input": input_value,
        "max_output_tokens": max_output_tokens,
    }
    if schema is not None:
        kwargs["text"] = {"format": {"type": "json_schema", "name": name, "strict": True, "schema": schema}}
    response = _responses_create(**kwargs)
    return response.output_text.strip()

@app.get("/health")
def health():
    return {"ok": True, "model": MODEL, "material_loaded": bool(last_material["name"])}

@app.get("/license/status")
def license_status(device_id: str = ""):
    return {"active": _is_active(device_id.strip()), "device_id": device_id.strip()}


@app.get("/admin", response_class=HTMLResponse)
def admin_page():
    return HTMLResponse(r'''<!doctype html>
<html lang="ar" dir="rtl">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Study AI — لوحة المطوّر</title>
<style>
:root{--bg:#f3f7fb;--card:#fff;--text:#172033;--muted:#64748b;--primary:#0f6ea7;--border:#dbe6ef}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--text);font-family:Arial,Tahoma,sans-serif;padding:14px}
.wrap{max-width:1200px;margin:auto}.box{background:var(--card);border:1px solid var(--border);border-radius:20px;padding:18px;box-shadow:0 10px 35px #0000000d;margin-bottom:14px}
h1{margin:0 0 5px;font-size:24px}.muted{color:var(--muted);font-size:13px}.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}
input,select,button{width:100%;padding:12px;border-radius:11px;border:1px solid var(--border);font-size:14px}
button{border:0;background:var(--primary);color:#fff;font-weight:800;cursor:pointer}.danger{background:#b42318}.secondary{background:#edf6fb;color:#0f6ea7}
.actions{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:10px}.search{margin-top:10px}
.tablewrap{overflow:auto;margin-top:12px}table{width:100%;border-collapse:collapse;min-width:1050px}
th,td{padding:9px;border-bottom:1px solid var(--border);text-align:right;white-space:nowrap}th{background:#eef6fb}
.badge{display:inline-block;padding:4px 8px;border-radius:999px;font-size:11px;font-weight:800}.active{background:#dcfce7;color:#166534}.revoked{background:#fee2e2;color:#991b1b}.expired{background:#ffedd5;color:#9a3412}
.row-actions{display:flex;gap:5px}.row-actions button{width:auto;padding:7px 9px;font-size:11px}
pre{white-space:pre-wrap;word-break:break-word;background:#0b1420;color:#dceeff;padding:12px;border-radius:12px;max-height:300px;overflow:auto}
@media(max-width:700px){.grid,.actions{grid-template-columns:1fr}.box{padding:13px}h1{font-size:20px}}
</style>
</head>
<body><div class="wrap">
<div class="box">
<h1>🛠️ Study AI — لوحة المطوّر</h1>
<p class="muted">إدارة العملاء والاشتراكات والتفعيل وحصة الذكاء الاصطناعي.</p>
<div class="grid">
<input id="key" type="password" placeholder="Developer Key">
<input id="device" placeholder="Device ID">
<input id="customer" placeholder="اسم العميل">
<select id="duration"><option value="7">7 أيام</option><option value="14">14 يوم</option><option value="30" selected>شهر</option><option value="60">شهران</option></select>
<input id="start" type="date">
<input id="quota" type="number" min="0" value="100000" placeholder="AI quota">
</div>
<div class="actions"><button onclick="activate()">تفعيل / حفظ</button><button onclick="extend()">تمديد</button><button class="danger" onclick="revoke()">إلغاء التفعيل</button></div>
<button class="secondary" style="margin-top:8px" onclick="listAll()">تحديث جدول العملاء</button>
<input id="search" class="search" oninput="filterTable()" placeholder="🔎 بحث باسم العميل أو Device ID">
</div>
<div class="box"><h2>العملاء</h2><div class="tablewrap"><table>
<thead><tr><th>العميل</th><th>Device ID</th><th>الاشتراك</th><th>البداية</th><th>الانتهاء</th><th>الحالة</th><th>AI</th><th>إجراءات</th></tr></thead>
<tbody id="rows"><tr><td colspan="8" class="muted">اضغط تحديث جدول العملاء.</td></tr></tbody></table></div></div>
<div class="box"><h2>تفاصيل العميل</h2><pre id="details">اختر "تفاصيل" من الجدول.</pre></div>
<div class="box"><h2>سجل العمليات</h2><pre id="history">اختر عميلاً لعرض السجل.</pre></div>
<div class="box"><pre id="out"></pre></div>
</div>
<script>
let DATA=[];
const key=()=>document.getElementById('key').value.trim();
const esc=v=>String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
function body(){return{device_id:document.getElementById('device').value.trim(),customer:document.getElementById('customer').value.trim(),duration_days:Number(document.getElementById('duration').value),ai_quota:Number(document.getElementById('quota').value||0),start_date:document.getElementById('start').value||null}}
async function call(path){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Admin-Key':key()},body:JSON.stringify(body())});const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.detail||'فشل الطلب');document.getElementById('out').textContent=JSON.stringify(j,null,2);return j}
async function activate(){try{await call('/admin/activate');await listAll()}catch(e){alert(e.message)}}
async function extend(){try{await call('/admin/extend');await listAll()}catch(e){alert(e.message)}}
async function revoke(){if(!confirm('إلغاء تفعيل هذا الجهاز؟'))return;try{await call('/admin/revoke');await listAll()}catch(e){alert(e.message)}}
function status(x){if(x.status==='revoked')return '<span class="badge revoked">ملغى</span>';if(x.expires_at&&new Date(x.expires_at)<=new Date())return '<span class="badge expired">منتهي</span>';return '<span class="badge active">فعال</span>'}
function render(a){document.getElementById('rows').innerHTML=a.map(x=>{let pct=x.ai_quota?Math.min(100,Math.round((x.ai_used||0)/x.ai_quota*100)):0;return `<tr><td>${esc(x.customer||'—')}</td><td dir="ltr">${esc(x.device_id)}</td><td>${x.duration_days||'—'} يوم</td><td dir="ltr">${esc(x.started_at||'—')}</td><td dir="ltr">${esc(x.expires_at||'—')}</td><td>${status(x)}</td><td>${x.ai_used||0} / ${x.ai_quota||0} (${pct}%)</td><td class="row-actions"><button onclick="details('${encodeURIComponent(x.device_id)}')">تفاصيل</button><button class="secondary" onclick="loadCustomer('${encodeURIComponent(x.device_id)}')">تعديل</button></td></tr>`}).join('')||'<tr><td colspan="8">لا يوجد عملاء.</td></tr>'}
async function listAll(){try{const r=await fetch('/admin/licenses',{headers:{'X-Admin-Key':key()}});const j=await r.json();if(!r.ok)throw new Error(j.detail||'فشل');DATA=j.licenses||[];render(DATA);document.getElementById('out').textContent='تم تحديث الجدول: '+DATA.length+' عميل.'}catch(e){document.getElementById('out').textContent='❌ '+e.message}}
function filterTable(){let q=document.getElementById('search').value.toLowerCase();render(DATA.filter(x=>(x.customer||'').toLowerCase().includes(q)||(x.device_id||'').toLowerCase().includes(q)))}
async function details(encoded){let id=decodeURIComponent(encoded);try{const r=await fetch('/admin/license/'+encodeURIComponent(id),{headers:{'X-Admin-Key':key()}});const j=await r.json();if(!r.ok)throw new Error(j.detail||'فشل');document.getElementById('details').textContent=JSON.stringify(j.license,null,2);document.getElementById('history').textContent=JSON.stringify(j.history||[],null,2)}catch(e){alert(e.message)}}
function loadCustomer(encoded){let id=decodeURIComponent(encoded),x=DATA.find(a=>a.device_id===id);if(!x)return;document.getElementById('device').value=x.device_id;document.getElementById('customer').value=x.customer||'';document.getElementById('duration').value=[7,14,30,60].includes(Number(x.duration_days))?x.duration_days:30;document.getElementById('quota').value=x.ai_quota||100000;document.getElementById('start').value=(x.started_at||'').slice(0,10);window.scrollTo({top:0,behavior:'smooth'})}
</script></body></html>''')
class LicenseRequest(BaseModel):
    device_id: str
    customer: str = ""
    expires_at: str | None = None
    duration_days: int = 30
    ai_quota: int = 100000
    start_date: str | None = None

@app.post("/admin/activate")
def admin_activate(body: LicenseRequest, request: Request):
    require_admin(request)
    device_id=body.device_id.strip()
    if not device_id: raise HTTPException(400,"Device ID مطلوب.")
    days=body.duration_days if body.duration_days in (7,14,30,60) else 30
    from datetime import datetime, timedelta, timezone
    if body.start_date:
        try: started_dt=datetime.fromisoformat(body.start_date).replace(tzinfo=timezone.utc)
        except Exception: raise HTTPException(400,"تاريخ البداية غير صحيح.")
    else: started_dt=datetime.now(timezone.utc)
    started=started_dt.isoformat()
    expires=body.expires_at.strip() if body.expires_at else (started_dt+timedelta(days=days)).isoformat()
    quota=max(0,int(body.ai_quota))
    con=_license_db()
    try:
        con.execute("INSERT INTO licenses(device_id,customer,status,created_at,started_at,expires_at,duration_days,ai_quota,ai_used) VALUES(?,?,?,CURRENT_TIMESTAMP,?,?,?,?,0) ON CONFLICT(device_id) DO UPDATE SET customer=excluded.customer,status='active',started_at=excluded.started_at,expires_at=excluded.expires_at,duration_days=excluded.duration_days,ai_quota=excluded.ai_quota,ai_used=0",(device_id,body.customer.strip(),"active",started,expires,days,quota))
        _log_history(con,device_id,"activate",f"customer={body.customer.strip()} duration={days} quota={quota}")
        con.commit()
    finally: con.close()
    return {"ok":True,"device_id":device_id,"status":"active","customer":body.customer.strip(),"started_at":started,"expires_at":expires,"duration_days":days,"ai_quota":quota,"ai_used":0}

@app.post("/admin/revoke")
def admin_revoke(body: LicenseRequest, request: Request):
    require_admin(request)
    con=_license_db()
    try:
        con.execute("UPDATE licenses SET status='revoked' WHERE device_id=?",(body.device_id.strip(),))
        _log_history(con,body.device_id.strip(),"revoke","")
        con.commit()
    finally: con.close()
    return {"ok":True,"device_id":body.device_id.strip(),"status":"revoked"}

@app.post("/admin/extend")
def admin_extend(body: LicenseRequest, request: Request):
    require_admin(request)
    device_id=body.device_id.strip(); days=body.duration_days if body.duration_days in (7,14,30,60) else 30
    from datetime import datetime,timedelta,timezone
    con=_license_db()
    try:
        row=con.execute("SELECT expires_at,duration_days FROM licenses WHERE device_id=?",(device_id,)).fetchone()
        if not row: raise HTTPException(404,"العميل غير موجود.")
        base=datetime.now(timezone.utc)
        if row[0]:
            try: base=max(base,datetime.fromisoformat(row[0].replace("Z","+00:00")))
            except Exception: pass
        exp=(base+timedelta(days=days)).isoformat()
        con.execute("UPDATE licenses SET status='active',expires_at=?,duration_days=COALESCE(duration_days,0)+? WHERE device_id=?",(exp,days,device_id))
        _log_history(con,device_id,"extend",f"extended_days={days}")
        con.commit()
    finally: con.close()
    return {"ok":True,"device_id":device_id,"expires_at":exp,"extended_days":days}

@app.get("/admin/licenses")
def admin_licenses(request: Request):
    require_admin(request)
    con=_license_db()
    try: rows=con.execute("SELECT device_id,customer,status,created_at,started_at,expires_at,duration_days,ai_quota,ai_used,last_used_at FROM licenses ORDER BY created_at DESC").fetchall()
    finally: con.close()
    keys=["device_id","customer","status","created_at","started_at","expires_at","duration_days","ai_quota","ai_used","last_used_at"]
    return {"licenses":[dict(zip(keys,r)) for r in rows]}

@app.get("/admin/license/{device_id}")
def admin_license_detail(device_id: str, request: Request):
    require_admin(request)
    con=_license_db()
    try:
        row=con.execute("SELECT device_id,customer,status,created_at,started_at,expires_at,duration_days,ai_quota,ai_used,last_used_at FROM licenses WHERE device_id=?",(device_id,)).fetchone()
        if not row: raise HTTPException(404,"العميل غير موجود.")
        keys=["device_id","customer","status","created_at","started_at","expires_at","duration_days","ai_quota","ai_used","last_used_at"]
        hist=con.execute("SELECT action,details,created_at FROM license_history WHERE device_id=? ORDER BY id DESC LIMIT 100",(device_id,)).fetchall()
        return {"license":dict(zip(keys,row)),"history":[{"action":x[0],"details":x[1],"created_at":x[2]} for x in hist]}
    finally:
        con.close()

class AITestRequest(BaseModel):
    question: str = "Reply with exactly: OK"

@app.post("/ai/test")
def ai_test(body: AITestRequest, request: Request):
    device_id=require_activation(request)
    q=(body.question or "Reply with exactly: OK").strip()[:200]
    _consume_ai(device_id,200)
    try:
        answer=ask_ai_with_optional_material("Perform a connectivity test. Reply briefly and do not use any study material. User request:\n"+q,max_output_tokens=30)
        return {"ok":True,"answer":answer,"model":MODEL}
    except Exception as exc:
        msg=str(exc).lower()
        if "429" in msg or "rate_limit" in msg:
            raise HTTPException(429,"الـAI متصل بالخادم لكن OpenAI رفض الطلب حالياً بسبب حدود الاستخدام.")
        raise HTTPException(502,f"اختبار AI فشل: {exc}")

@app.post("/analyze")
async def analyze(request: Request, file: UploadFile = File(...)):
    require_activation(request)

    data = await file.read()
    mime = file.content_type or ""
    text = extract_text(data, file.filename)

    if not text and not mime.startswith("image/"):
        raise HTTPException(
            400,
            "لم أستطع استخراج النص من هذا الملف. استخدم PDF/DOCX/PPTX أو صورة واضحة."
        )

    last_material["name"] = file.filename
    last_material["text"] = text
    last_material["mime"] = mime
    last_material["image_data"] = (
        base64.b64encode(data).decode("ascii") if mime.startswith("image/") else None
    )

    prompt = """حلّل المادة الدراسية تحليلاً شاملاً، ثم أعد النتيجة كـ JSON صالح فقط، بدون Markdown وبدون أي نص خارج JSON.
استخدم هذه المفاتيح حرفياً:
{
  "title": "اسم المادة أو الموضوع",
  "summary": "ملخص واضح",
  "difficulty": "سهل/متوسط/صعب",
  "understanding": 0,
  "high_yield": ["نقاط High-Yield"],
  "topics": ["المواضيع الرئيسية"],
  "must_memorize": ["ما يجب حفظه"],
  "must_understand": ["ما يجب فهمه"],
  "terms": [{"english":"", "arabic":"", "explanation":""}],
  "comparisons": ["مقارنات مهمة"],
  "rewrite": "A clear, organized English rewrite of the study material, preserving the original scientific meaning and important terminology.",
  "study_plan": ["خطوات مرتبة لدراسة المادة"],
  "quick_revision": ["نقاط مراجعة سريعة"],
  "questions": [{"question":"", "options":["A) ","B) ","C) ","D) "], "answer":"", "explanation":""}],
  "flashcards": [{"front":"", "back":""}]
}
اجعل understanding رقماً من 0 إلى 100 يمثل وضوح المادة واستيعاب بنيتها، وليس تشخيصاً لمستوى الطالب.
لا تضع معلومات غير موجودة في المادة إلا إذا وسمتها داخل النص بأنها "معلومة إضافية".
"""

    full_schema = {
        "type": "object", "additionalProperties": False,
        "properties": {
            "title": {"type": "string"}, "summary": {"type": "string"}, "difficulty": {"type": "string"},
            "understanding": {"type": "integer", "minimum": 0, "maximum": 100},
            "high_yield": {"type": "array", "items": {"type": "string"}},
            "topics": {"type": "array", "items": {"type": "string"}},
            "must_memorize": {"type": "array", "items": {"type": "string"}},
            "must_understand": {"type": "array", "items": {"type": "string"}},
            "terms": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"english": {"type": "string"}, "arabic": {"type": "string"}, "explanation": {"type": "string"}}, "required": ["english", "arabic", "explanation"]}},
            "comparisons": {"type": "array", "items": {"type": "string"}}, "rewrite": {"type": "string"},
            "study_plan": {"type": "array", "items": {"type": "string"}}, "quick_revision": {"type": "array", "items": {"type": "string"}},
            "questions": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"question": {"type": "string"}, "options": {"type": "array", "items": {"type": "string"}}, "answer": {"type": "string"}, "explanation": {"type": "string"}}, "required": ["question", "options", "answer", "explanation"]}},
            "flashcards": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"front": {"type": "string"}, "back": {"type": "string"}}, "required": ["front", "back"]}}
        },
        "required": ["title", "summary", "difficulty", "understanding", "high_yield", "topics", "must_memorize", "must_understand", "terms", "comparisons", "rewrite", "study_plan", "quick_revision", "questions", "flashcards"]
    }

    chunk_schema = {
        "type": "object", "additionalProperties": False,
        "properties": {
            "title": {"type": "string"}, "summary": {"type": "string"},
            "high_yield": {"type": "array", "items": {"type": "string"}},
            "topics": {"type": "array", "items": {"type": "string"}},
            "must_memorize": {"type": "array", "items": {"type": "string"}},
            "must_understand": {"type": "array", "items": {"type": "string"}},
            "terms": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"english": {"type": "string"}, "arabic": {"type": "string"}, "explanation": {"type": "string"}}, "required": ["english", "arabic", "explanation"]}},
            "comparisons": {"type": "array", "items": {"type": "string"}}
        },
        "required": ["title", "summary", "high_yield", "topics", "must_memorize", "must_understand", "terms", "comparisons"]
    }

    device_id=(request.headers.get("X-Device-ID") or "").strip()
    _consume_ai(device_id,max(500,min(18000,len(text[:LARGE_FILE_CHARS])//4+5000)))

    # Small/medium files: one request, with a hard input cap that stays below the rate limit.
    if len(text) <= LARGE_FILE_CHARS:
        try:
            raw = ask_ai(prompt, text_override=text[:LARGE_FILE_CHARS], schema=full_schema, name="study_analysis", max_output_tokens=5000)
            result = json.loads(raw)
            return {"filename": file.filename, "model": MODEL, "analysis": result}
        except Exception as exc:
            if "rate_limit" in str(exc).lower() or "429" in str(exc):
                raise HTTPException(429, "تم تجاوز حد التوكنات مؤقتاً. انتظر قليلاً ثم أعد المحاولة.")
            raise HTTPException(502, f"فشل تحليل المادة: {exc}")

    # Large files: analyze sequential chunks, then synthesize the compact chunk results.
    chunks = []
    pos = 0
    while pos < len(text):
        end = min(len(text), pos + CHUNK_CHARS)
        chunks.append(text[pos:end])
        if end >= len(text):
            break
        pos = max(end - 1200, pos + 1)  # small overlap keeps definitions across boundaries

    partials = []
    for i, chunk in enumerate(chunks, 1):
        instruction = f"حلّل الجزء {i} من {len(chunks)} من المادة فقط. استخرج المعلومات المهمة الموجودة فعلياً في هذا الجزء، ولا تخترع معلومات. كن مختصراً لأن هذه نتيجة وسيطة ستُدمج لاحقاً."
        try:
            raw = ask_ai(instruction, text_override=chunk, schema=chunk_schema, name="study_chunk", max_output_tokens=2200)
            partials.append(json.loads(raw))
        except Exception as exc:
            if "rate_limit" in str(exc).lower() or "429" in str(exc):
                raise HTTPException(429, "الملف كبير جداً على حد التوكنات الحالي. أعد المحاولة بعد دقيقة.")
            raise HTTPException(502, f"فشل تحليل الجزء {i}: {exc}")
        time.sleep(1.2)

    combined = json.dumps(partials, ensure_ascii=False)
    final_instruction = """ادمج نتائج تحليل أجزاء المادة التالية في تحليل نهائي واحد. لا تضف معلومات غير موجودة في نتائج الأجزاء. احذف التكرار، وحافظ على أهم النقاط والمصطلحات، ثم أنشئ النتيجة الكاملة بالمخطط المطلوب.\n\nنتائج الأجزاء:\n""" + combined
    try:
        raw = ask_ai(final_instruction, text_override="", schema=full_schema, name="study_analysis", max_output_tokens=2600)
        result = json.loads(raw)
    except Exception as exc:
        if "rate_limit" in str(exc).lower() or "429" in str(exc):
            raise HTTPException(429, "تم تجاوز حد التوكنات مؤقتاً أثناء تجميع التحليل. أعد المحاولة بعد دقيقة.")
        raise HTTPException(502, f"فشل تجميع التحليل: {exc}")

    return {"filename": file.filename, "model": MODEL, "analysis": result}



def ask_feature(instruction: str, max_output_tokens: int = 1600) -> str:
    """Run feature requests with bounded context to reduce TPM bursts."""
    text = last_material.get("text", "")
    if not text:
        return ask_ai(instruction, max_output_tokens=max_output_tokens)

    # Rewrite/translation can be assembled from smaller sections.
    if len(text) <= 18000:
        return ask_ai(instruction, text_override=text, max_output_tokens=max_output_tokens)

    parts = []
    step = 12000
    overlap = 600
    pos = 0
    while pos < len(text):
        end = min(len(text), pos + step)
        chunk = text[pos:end]
        parts.append(ask_ai(
            instruction + f"\n\nهذا الجزء {len(parts)+1} من المادة. عالج هذا الجزء فقط وحافظ على المصطلحات المهمة.",
            text_override=chunk,
            max_output_tokens=max_output_tokens,
        ))
        if end >= len(text):
            break
        pos = max(end - overlap, pos + 1)
        time.sleep(0.8)

    return "\n\n---\n\n".join(parts)

FEATURE_PROMPTS = {
    "rewrite": """Rewrite the uploaded study material in clear professional ENGLISH as an organized study handout. Keep the scientific meaning, important details, headings, definitions, mechanisms, numbers, units, and medical/pharmaceutical terminology. Do not translate it to Arabic in this mode. Do not invent information.""",
    "translate_ar": """Translate the uploaded study material into accurate medical/pharmaceutical ARABIC. Keep the original English term beside the Arabic translation when useful. Preserve headings, definitions, mechanisms, numbers, units, and important details. Do not invent information.""",
    "study": """أنشئ خطة دراسة عملية لهذه المادة: ترتيب المواضيع، ماذا أحفظ، ماذا أفهم، ثم أسئلة ومراجعة. اجعلها مناسبة لطالب طب/صيدلة.""",
    "questions": """أنشئ أسئلة امتحانية من المادة، متنوعة بين MCQ وأسئلة فهم. اذكر الإجابة الصحيحة وسببها. لا تدّعِ أن أي سؤال مضمون في الامتحان.""",
    "flashcards": """أنشئ Flashcards تغطي التعاريف والمصطلحات والآليات والأرقام والمقارنات المهمة في المادة. كل بطاقة سؤال/مصطلح ثم جواب مختصر.""",
    "terms": """استخرج أهم المصطلحات الطبية والصيدلانية من المادة في جدول نصي: English | العربية | شرح مبسط.""",
    "revision": """أنشئ مراجعة سريعة جداً للمادة: أهم ما يجب حفظه، أهم ما يجب فهمه، الأخطاء الشائعة، ونقاط High-Yield.""",
    "progress": """قيّم بنية المادة وصعوبتها ووضوحها، ثم أعطِ خطة لتحسين الدراسة. لا تدّعي معرفة مستوى الطالب الحقيقي دون بيانات اختبار.""",
    "drug": """اعمل بطاقة تعليمية عن الدواء أو المادة الفعالة المذكورة في السؤال اعتماداً على المادة المرفوعة أولاً. اذكر: الاسم العلمي، الفئة الدوائية، آلية العمل إذا كانت موجودة، الاستعمالات العامة المذكورة، الأشكال الصيدلانية/التراكيز إن وردت، أهم التحذيرات أو الآثار الجانبية إن وردت. لا تعطِ جرعة شخصية أو وصفة علاجية. إذا لم تكن المعلومة في الملف فقل ذلك بوضوح، وأي معرفة إضافية ابدأها بعبارة "معلومة إضافية".""",
}


class FeatureRequest(BaseModel):
    feature: str
    query: str = ""

def _feature_instruction(feature: str, query: str = ""):
    instruction = FEATURE_PROMPTS.get(feature)
    if not instruction:
        raise HTTPException(400, "الميزة غير معروفة.")
    if query.strip():
        instruction += "\n\nموضوع/طلب الطالب: " + query.strip()
    return instruction

def _material_from_upload(data: bytes, filename: str, mime: str):
    text = extract_text(data, filename)
    image_data = base64.b64encode(data).decode("ascii") if mime.startswith("image/") else None
    if not text and not image_data:
        raise HTTPException(400, "لم أستطع قراءة هذا الملف. استخدم PDF/DOCX/PPTX/TXT أو صورة واضحة.")
    return text, image_data, mime

def ask_ai_with_optional_material(instruction: str, text: str = "", image_data: str | None = None, mime: str = "", max_output_tokens: int = 1600) -> str:
    require_client()
    if image_data:
        input_value=[{"role":"user","content":[{"type":"input_text","text":instruction},{"type":"input_image","image_url":f"data:{mime};base64,{image_data}"}]}]
    elif text:
        input_value=instruction+"\n\nSTUDY MATERIAL PROVIDED FOR THIS REQUEST:\n"+text[:LARGE_FILE_CHARS]
    else:
        input_value=instruction
    response=_responses_create(model=MODEL,instructions=SYSTEM,input=input_value,max_output_tokens=max_output_tokens)
    return response.output_text.strip()

@app.post("/feature")
def feature(body: FeatureRequest, request: Request):
    device_id=require_activation(request)
    instruction=_feature_instruction(body.feature, body.query)
    estimate=max(300,min(6000,len(body.query)*4+1200))
    _consume_ai(device_id,estimate)
    try:
        return {"feature":body.feature,"answer":ask_ai_with_optional_material(instruction,max_output_tokens=1600)}
    except Exception as exc:
        msg=str(exc).lower()
        if "429" in msg or "rate_limit" in msg: raise HTTPException(429,"تم الوصول إلى حد AI مؤقتاً. انتظر ثم أعد المحاولة.")
        raise HTTPException(502,f"فشل تنفيذ الميزة: {exc}")

@app.post("/feature-file")
async def feature_file(request: Request, feature: str = "", query: str = "", file: UploadFile = File(...)):
    device_id=require_activation(request)
    instruction=_feature_instruction(feature, query)
    data=await file.read()
    text,image_data,mime=_material_from_upload(data,file.filename,file.content_type or "")
    estimate=max(500,min(9000,len(text)//8+len(query)//2+1500))
    _consume_ai(device_id,estimate)
    try:
        answer=ask_ai_with_optional_material(instruction,text,image_data,mime,max_output_tokens=1800)
        return {"feature":feature,"filename":file.filename,"answer":answer}
    except Exception as exc:
        msg=str(exc).lower()
        if "429" in msg or "rate_limit" in msg: raise HTTPException(429,"تم الوصول إلى حد AI مؤقتاً. انتظر ثم أعد المحاولة.")
        raise HTTPException(502,f"فشل تنفيذ الميزة: {exc}")

class ChatRequest(BaseModel):
    question: str

@app.post("/chat")
def chat(body: ChatRequest, request: Request):
    device_id=require_activation(request)
    q=body.question.strip()
    if not q: raise HTTPException(400,"اكتب السؤال.")
    instruction=f"""أجب عن سؤال الطالب بشكل مباشر وواضح. لا تفترض وجود ملف أو مادة دراسية إذا لم يتم إرفاقها في هذا الطلب. إذا كان السؤال طبياً أو صيدلانياً فاجعله تعليمياً ولا تعطِ وصفة شخصية أو جرعة شخصية.\n\nسؤال الطالب:\n{q}"""
    _consume_ai(device_id,max(300,min(5000,len(q)//2+900)))
    try:
        return {"answer":ask_ai_with_optional_material(instruction,max_output_tokens=800)}
    except Exception as exc:
        msg=str(exc).lower()
        if "429" in msg or "rate_limit" in msg: raise HTTPException(429,"تم الوصول إلى حد AI مؤقتاً. انتظر ثم أعد المحاولة.")
        raise HTTPException(502,f"فشل اتصال AI: {exc}")

@app.post("/chat-file")
async def chat_file(request: Request, question: str = "", file: UploadFile = File(...)):
    device_id=require_activation(request)
    q=question.strip()
    if not q: raise HTTPException(400,"اكتب السؤال.")
    data=await file.read()
    text,image_data,mime=_material_from_upload(data,file.filename,file.content_type or "")
    instruction=f"""أجب عن سؤال الطالب اعتماداً على الملف المرفق أولاً. إذا لم تجد الإجابة في الملف، وضّح ذلك ثم استخدم معرفتك العامة عند الحاجة وسمها بوضوح: معلومة إضافية. لا تخترع معلومات. إذا كان السؤال طبياً أو صيدلانياً فاجعله تعليمياً ولا تعطِ وصفة شخصية أو جرعة شخصية.\n\nسؤال الطالب:\n{q}"""
    _consume_ai(device_id,max(400,min(6500,len(text)//8+len(q)//2+900)))
    try:
        return {"answer":ask_ai_with_optional_material(instruction,text,image_data,mime,max_output_tokens=900),"filename":file.filename}
    except Exception as exc:
        msg=str(exc).lower()
        if "429" in msg or "rate_limit" in msg: raise HTTPException(429,"تم الوصول إلى حد AI مؤقتاً. انتظر ثم أعد المحاولة.")
        raise HTTPException(502,f"فشل اتصال AI: {exc}")

@app.post("/reset")
def reset():
    last_material.update({"name": None, "text": "", "image_data": None, "mime": None})
    return {"ok": True}
