package com.studyai.app

import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Notification
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.Manifest
import android.content.pm.PackageManager
import android.webkit.*
import android.content.Intent
import android.provider.Settings
import android.content.ClipData
import android.content.ClipboardManager
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.graphics.Color
import androidx.core.content.FileProvider
import androidx.core.app.NotificationCompat
import java.io.File

class MainActivity : Activity() {
    companion object {
        private const val CHANNEL_ID = "studyai_updates"
        private const val NOTIFY_ID = 2201
        private const val DEFAULT_BACKEND = "https://studyai-i5vt.onrender.com"
    }

    private var uploadCallback: ValueCallback<Array<Uri>>? = null
    private val PICK_FILE = 1001

    private fun setupNotifications() {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Study AI",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply { description = "إشعارات اكتمال تحليل الملفات في Study AI" }
            manager.createNotificationChannel(channel)
        }
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2202)
        }
    }

    private fun notifyStudyComplete(fileName: String) {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        try {
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.pharmacy_logo)
                .setContentTitle("Study AI — تم الانتهاء ✅")
                .setContentText("تم تحليل الملف: $fileName")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFY_ID, notification)
        } catch (_: Exception) {
            // A notification failure must never close Study AI after a successful analysis.
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setupNotifications()

        val root = FrameLayout(this)
        val web = WebView(this)
        val splash = ImageView(this).apply {
            setImageResource(R.drawable.studyai_splash)
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.WHITE)
            contentDescription = "Study AI"
        }

        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        root.addView(splash, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        web.settings.useWideViewPort = true
        web.settings.loadWithOverviewMode = false

        web.addJavascriptInterface(object {
            @JavascriptInterface
            fun notifyStudyComplete(fileName: String) {
                runOnUiThread { notifyStudyComplete(fileName) }
            }

            @JavascriptInterface
            fun shareText(text: String) {
                runOnUiThread {
                    try {
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        startActivity(Intent.createChooser(share, "مشاركة Study AI"))
                    } catch (e: Exception) { }
                }
            }

            @JavascriptInterface
            fun openInstagram() {
                runOnUiThread {
                    try {
                        val appUri = Uri.parse("instagram://user?username=g.9.g.g")
                        startActivity(Intent(Intent.ACTION_VIEW, appUri))
                    } catch (e: Exception) {
                        startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://instagram.com/g.9.g.g")))
                    }
                }
            }

            @JavascriptInterface
            fun getDeviceId(): String {
                return Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
            }

            @JavascriptInterface
            fun copyText(text: String) {
                val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Study AI", text))
            }

            @JavascriptInterface
            fun shareApp() {
                runOnUiThread {
                    try {
                        val apkFile = File(cacheDir, "StudyAI.apk")
                        File(applicationInfo.sourceDir).copyTo(apkFile, overwrite = true)
                        val uri = FileProvider.getUriForFile(
                            this@MainActivity,
                            "${packageName}.fileprovider",
                            apkFile
                        )
                        val share = Intent(Intent.ACTION_SEND).apply {
                            type = "application/vnd.android.package-archive"
                            putExtra(Intent.EXTRA_STREAM, uri)
                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        startActivity(Intent.createChooser(share, "إرسال نسخة Study AI"))
                    } catch (e: Exception) {
                        // Keep the app usable if the device blocks APK sharing.
                    }
                }
            }
        }, "Android")

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                uploadCallback?.onReceiveValue(null)
                uploadCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
                intent.addCategory(Intent.CATEGORY_OPENABLE)
                intent.type = "*/*"
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                startActivityForResult(intent, PICK_FILE)
                return true
            }
        }

        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                view?.evaluateJavascript(
                    "window.APP_VERSION='${BuildConfig.VERSION_NAME}'; window.DEFAULT_BACKEND='${DEFAULT_BACKEND}'; if(window.initApp) window.initApp();",
                    null
                )
            }
        }

        web.loadUrl("file:///android_asset/index.html")

        Handler(Looper.getMainLooper()).postDelayed({
            splash.animate().alpha(0f).setDuration(350).withEndAction {
                root.removeView(splash)
            }.start()
        }, 1500)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_FILE) {
            val result = if (resultCode == RESULT_OK && data?.data != null)
                arrayOf(data.data!!)
            else null
            uploadCallback?.onReceiveValue(result)
            uploadCallback = null
        }
    }
}
