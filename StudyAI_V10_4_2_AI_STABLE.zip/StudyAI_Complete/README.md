# Study AI 10.4.0

Medical & Pharmacy Study Assistant.

## Current architecture
- No Device ID activation gate in the app.
- Independent AI chat; file attachment is optional.
- PDF/DOCX/PPTX/TXT/Markdown/image upload support where applicable.
- Study tools: analysis, rewrite, translation, study plan, questions, flashcards, terms, quick revision, progress and drug education.
- Pro-ready feature area for future subscriptions and additional languages.
- HTTPS backend only.
- Notifications are requested only on Android 13+ when needed.

## Important
The current release is a no-login/no-activation build. Subscription/payment enforcement is intentionally left for a later Pro release so it can be implemented with a real account/payment system rather than a Device ID gate.
