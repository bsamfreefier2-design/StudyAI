import os
import base64
import io
import json
import re
import time
import sqlite3
from pathlib import Path

from fastapi import FastAPI, UploadFile, File, HTTPException, Request
from fastapi.responses import HTMLResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI

try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None
try:
    from docx import Document
except Exception:
    Document = None
try:
    from pptx import Presentation
except Exception:
    Presentation = None

app = FastAPI(title="Study AI Backend", version="4.0")

origins = [x.strip() for x in os.getenv("ALLOWED_ORIGINS", "*").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins or ["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

API_KEY = os.getenv("OPENAI_API_KEY")
MODEL = os.getenv("OPENAI_MODEL", "gpt-5.6-luna")
client = OpenAI(api_key=API_KEY) if API_KEY else None

# Large-file protection: keep each AI request comfortably below the TPM limit.
CHUNK_CHARS = int(os.getenv("AI_CHUNK_CHARS", "8000"))
LARGE_FILE_CHARS = int(os.getenv("AI_LARGE_FILE_CHARS", "16000"))
MAX_RETRIES = 0


# Device activation / licensing
ADMIN_KEY = os.getenv("STUDYAI_ADMIN_KEY", "")
LICENSE_DB_PATH = os.getenv("LICENSE_DB_PATH", "/data/studyai_licenses.db")


def _license_db():
    path = Path(LICENSE_DB_PATH)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        path = Path("/tmp/studyai_licenses.db")
    con = sqlite3.connect(str(path), timeout=10)
    con.execute("""
        CREATE TABLE IF NOT EXISTS licenses (
            device_id TEXT PRIMARY KEY,
            customer TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT 'active',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            expires_at TEXT DEFAULT NULL,
            started_at TEXT DEFAULT NULL,
            duration_days INTEGER DEFAULT 30,
            ai_quota INTEGER DEFAULT 100000,
            ai_used INTEGER DEFAULT 0,
            last_used_at TEXT DEFAULT NULL
        )
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS license_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            device_id TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    """)
    # Upgrade databases created by older versions.
    for col, typ in [("started_at","TEXT"),("duration_days","INTEGER DEFAULT 30"),("ai_quota","INTEGER DEFAULT 100000"),("ai_used","INTEGER DEFAULT 0"),("last_used_at","TEXT DEFAULT NULL")]:
        try: con.execute(f"ALTER TABLE licenses ADD COLUMN {col} {typ}")
        except sqlite3.OperationalError: pass
    con.commit()
    return con


def _record_license_event(device_id: str, action: str, details: str = ""):
    con = _license_db()
    try:
        con.execute("INSERT INTO license_events(device_id,action,details) VALUES(?,?,?)",
                    (device_id.strip(), action, details[:2000]))
        con.commit()
    finally:
        con.close()

def _license_details(device_id: str):
    con = _license_db()
    try:
        row = con.execute(
            "SELECT device_id,customer,status,created_at,started_at,expires_at,duration_days,ai_quota,ai_used,last_used_at "
            "FROM licenses WHERE device_id=?", (device_id.strip(),)
        ).fetchone()
        if not row:
            return None
        keys=["device_id","customer","status","created_at","started_at","expires_at","duration_days","ai_quota","ai_used","last_used_at"]
        item=dict(zip(keys,row))
        ev=con.execute(
            "SELECT action,details,created_at FROM license_events WHERE device_id=? ORDER BY id DESC LIMIT 100",
            (device_id.strip(),)
        ).fetchall()
        item["events"]=[{"action":a,"details":d,"created_at":c} for a,d,c in ev]
        return item
    finally:
        con.close()

def _is_active(device_id: str) -> bool:
    if not device_id:
        return False
    con = _license_db()
    try:
        row = con.execute(
            "SELECT status, expires_at FROM licenses WHERE device_id=?",
            (device_id,)
        ).fetchone()
        if not row or row[0] != "active":
            return False
        if row[1]:
            from datetime import datetime, timezone
            try:
                exp = datetime.fromisoformat(row[1].replace("Z", "+00:00"))
                if exp.tzinfo is None:
                    exp = exp.replace(tzinfo=timezone.utc)
                if exp <= datetime.now(timezone.utc):
                    return False
            except Exception:
                pass
        return True
    finally:
        con.close()


def _is_expired(expires_at: str):
    from datetime import datetime, timezone
    try:
        exp=datetime.fromisoformat(expires_at.replace("Z","+00:00"))
        if exp.tzinfo is None: exp=exp.replace(tzinfo=timezone.utc)
        return exp <= datetime.now(timezone.utc)
    except Exception: return False

def _duration_expiry(days: int):
    from datetime import datetime, timedelta, timezone
    return (datetime.now(timezone.utc)+timedelta(days=days)).isoformat()

def _consume_ai(device_id: str, estimated_tokens: int):
    con=_license_db()
    try:
        row=con.execute("SELECT ai_quota,ai_used,status,expires_at FROM licenses WHERE device_id=?",(device_id,)).fetchone()
        if not row or row[2] != "active": raise HTTPException(403,"الترخيص غير فعال.")
        quota,used,status,expires=row
        if expires and _is_expired(expires): raise HTTPException(403,"انتهى الاشتراك. تواصل مع المطور للتجديد.")
        estimated_tokens=max(0,int(estimated_tokens))
        if quota and used+estimated_tokens>quota:
            raise HTTPException(429,"انتهت حصة الذكاء الاصطناعي لهذا الاشتراك. تواصل مع المطور لتجديد الحصة.")
        con.execute("UPDATE licenses SET ai_used=ai_used+?,last_used_at=CURRENT_TIMESTAMP WHERE device_id=?",(estimated_tokens,device_id)); con.commit()
    finally: con.close()

def require_activation(request: Request):
    device_id = (request.headers.get("X-Device-ID") or "").strip()
    if not _is_active(device_id):
        raise HTTPException(
            403,
            "هذا الجهاز غير مفعّل. أرسل Device ID إلى مطوّر Study AI للحصول على التفعيل."
        )
    return device_id


def require_admin(request: Request):
    if not ADMIN_KEY:
        raise HTTPException(503, "STUDYAI_ADMIN_KEY غير مضبوط على الخادم.")
    if request.headers.get("X-Admin-Key") != ADMIN_KEY:
        raise HTTPException(401, "مفتاح المطوّر غير صحيح.")


# Prototype storage for one user's latest uploaded material.
# For a multi-user production service, replace this with per-user/session storage.
last_material = {
    "name": None,
    "text": "",
    "image_data": None,
    "mime": None,
}

SYSTEM = """You are Study AI, an academic study assistant specialized in medical and pharmaceutical education.

Core rules:
- Use the uploaded study material as the primary source.
- Do not invent scientific facts, doses, drug names, numbers, units, abbreviations, or exam certainty.
- If the material is unclear or missing the answer, say so.
- If you add knowledge not present in the material, label it exactly as: "معلومة إضافية".
- For Arabic translation, use accurate medical/pharmaceutical terminology and keep the English term beside it when useful.
- Keep the material's meaning; do not silently omit important information.
- Prefer clear Arabic RTL-friendly headings and concise bullets.
- Never claim that a question is guaranteed to appear on an exam. Use "High-Yield" or "مرجّح للمراجعة".
"""

def require_client():
    if not client:
        raise HTTPException(503, "OPENAI_API_KEY غير مضبوط على الخادم.")

def extract_text(data: bytes, name: str) -> str:
    ext = Path(name).suffix.lower()
    if ext == ".pdf" and PdfReader:
        reader = PdfReader(io.BytesIO(data))
        return "\n\n".join((page.extract_text() or "") for page in reader.pages)
    if ext == ".docx" and Document:
        doc = Document(io.BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs if p.text.strip())
    if ext == ".pptx" and Presentation:
        prs = Presentation(io.BytesIO(data))
        parts = []
        for slide in prs.slides:
            for shape in slide.shapes:
                if hasattr(shape, "text") and shape.text.strip():
                    parts.append(shape.text)
        return "\n".join(parts)
    if ext in [".txt", ".md"]:
        return data.decode("utf-8", errors="replace")
    return ""

def clean_json(raw: str):
    raw = raw.strip()
    if raw.startswith("```"):
        raw = re.sub(r"^```(?:json)?\s*", "", raw, flags=re.I)
        raw = re.sub(r"\s*```$", "", raw)
    start = raw.find("{")
    end = raw.rfind("}")
    if start >= 0 and end > start:
        raw = raw[start:end + 1]
    return json.loads(raw)

def make_input(instruction: str):
    if last_material["image_data"]:
        return [{
            "role": "user",
            "content": [
                {"type": "input_text", "text": instruction},
                {
                    "type": "input_image",
                    "image_url": f"data:{last_material['mime']};base64,{last_material['image_data']}",
                },
            ],
        }]
    return instruction + "\n\nSTUDY MATERIAL:\n" + last_material["text"]

def _responses_create(**kwargs):
    require_client()
    return client.responses.create(**kwargs)

def ask_ai(instruction: str, text_override: str | None = None, schema=None, name="study_analysis", max_output_tokens=2500) -> str:
    require_client()
    if text_override is None:
        input_value = make_input(instruction)
    else:
        input_value = instruction + "\n\nSTUDY MATERIAL EXCERPT:\n" + text_override
    kwargs = {
        "model": MODEL,
        "instructions": SYSTEM,
        "input": input_value,
        "max_output_tokens": max_output_tokens,
    }
    if schema is not None:
        kwargs["text"] = {"format": {"type": "json_schema", "name": name, "strict": True, "schema": schema}}
    response = _responses_create(**kwargs)
    return response.output_text.strip()

@app.get("/health")
def health():
    return {"ok": True, "model": MODEL, "material_loaded": bool(last_material["name"])}

@app.get("/license/status")
def license_status(device_id: str = ""):
    item = _license_details(device_id.strip()) if device_id.strip() else None
    if not item:
        return {"active": False, "device_id": device_id.strip()}
    return {"active": _is_active(device_id.strip()), "device_id": device_id.strip(),
            "customer": item.get("customer",""), "expires_at": item.get("expires_at"),
            "duration_days": item.get("duration_days"), "ai_quota": item.get("ai_quota",0),
            "ai_used": item.get("ai_used",0)}


@app.get("/admin", response_class=HTMLResponse)
def admin_page():
    return HTMLResponse(r'''<!doctype html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Study AI — لوحة المطوّر</title>
<style>
:root{--bg:#eef4f9;--card:#fff;--text:#132235;--muted:#617387;--primary:#0b6ea8;--primary2:#1597c8;--border:#d9e4ed;--danger:#b42318}
*{box-sizing:border-box}body{margin:0;background:linear-gradient(135deg,#eef6fb,#f7fbfe);font-family:Arial,Tahoma,sans-serif;color:var(--text);padding:18px}
.wrap{max-width:1250px;margin:auto}.box{background:var(--card);border:1px solid var(--border);border-radius:24px;padding:20px;box-shadow:0 12px 40px #16405c12}
h1{margin:0;font-size:24px}.sub{color:var(--muted);margin:7px 0 18px}
.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.field label{display:block;font-size:12px;font-weight:800;color:var(--muted);margin:0 0 4px}
input,select,button{width:100%;padding:12px;border-radius:12px;border:1px solid var(--border);font-size:15px}
input,select{background:#fbfdff;color:var(--text)}button{background:linear-gradient(135deg,var(--primary),var(--primary2));color:#fff;border:0;font-weight:800;cursor:pointer;box-shadow:0 4px 12px #0b6ea81f}
button:active{transform:scale(.98)}button.secondary{background:#eaf4fa;color:var(--primary);box-shadow:none}button.danger{background:var(--danger)}
.actions{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-top:12px}
.toolbar{display:grid;grid-template-columns:1fr auto;gap:8px;margin-top:16px}.tablewrap{overflow:auto;margin-top:10px}
table{width:100%;border-collapse:separate;border-spacing:0;min-width:1050px}th,td{padding:10px;border-bottom:1px solid var(--border);text-align:right;white-space:nowrap}
th{background:#edf6fb;color:#24516e;font-size:12px;position:sticky;top:0}tr:hover td{background:#f8fbfd}.badge{display:inline-flex;padding:4px 9px;border-radius:999px;font-size:12px;font-weight:800}
.active{background:#dcfce7;color:#166534}.revoked{background:#fee2e2;color:#991b1b}.expired{background:#ffedd5;color:#9a3412}
.rowbtn{width:auto;padding:7px 9px;margin-left:4px;font-size:12px;box-shadow:none}.details{margin-top:14px;background:#f7fbfe;border:1px solid var(--border);border-radius:16px;padding:14px;display:none}.details h3{margin:0 0 8px}
pre{white-space:pre-wrap;word-break:break-word;color:#506276;font-size:11px}.hint{font-size:11px;color:var(--muted);margin-top:6px}
@media(max-width:800px){.grid{grid-template-columns:1fr 1fr}.actions{grid-template-columns:1fr 1fr}}
@media(max-width:520px){body{padding:8px}.box{padding:13px;border-radius:18px}.grid,.actions,.toolbar{grid-template-columns:1fr}}
</style></head>
<body><div class="wrap"><div class="box">
<h1>Study AI — لوحة المطوّر</h1>
<div class="sub">إدارة العملاء والاشتراكات وحصة الذكاء الاصطناعي وسجل العمليات.</div>
<div class="grid">
<div class="field"><label>Developer Key</label><input id="key" type="password" placeholder="مفتاح المطوّر"></div>
<div class="field"><label>اسم العميل</label><input id="customer" placeholder="اسم العميل"></div>
<div class="field"><label>Device ID</label><input id="device" placeholder="Device ID"></div>
<div class="field"><label>مدة الاشتراك</label><select id="duration"><option value="7">7 أيام</option><option value="14">14 يوم</option><option value="30" selected>شهر — 30 يوم</option><option value="60">شهرين — 60 يوم</option></select></div>
<div class="field"><label>حصة AI</label><input id="quota" type="number" min="0" value="100000" placeholder="التوكنات التقريبية"></div>
<div class="field"><label>تاريخ الانتهاء</label><input id="expires" placeholder="فارغ = حساب تلقائي"></div>
</div>
<div class="actions">
<button onclick="activate()">تفعيل / حفظ الاشتراك</button>
<button onclick="extend()" class="secondary">تمديد الاشتراك</button>
<button onclick="updateLicense()" class="secondary">تعديل العميل</button>
<button onclick="revoke()" class="danger">إلغاء التفعيل</button>
</div>
<div class="toolbar"><input id="search" oninput="filterTable()" placeholder="بحث باسم العميل أو Device ID">
<button onclick="listAll()" class="secondary" style="width:auto;padding:11px 18px">تحديث العملاء</button></div>
<div class="tablewrap"><table><thead><tr>
<th>العميل</th><th>Device ID</th><th>المدة</th><th>البداية</th><th>الانتهاء</th><th>الحالة</th><th>AI المستخدم / الحصة</th><th>آخر استخدام</th><th>إجراءات</th>
</tr></thead><tbody id="rows"><tr><td colspan="9" class="hint">أدخل Developer Key ثم اضغط تحديث العملاء.</td></tr></tbody></table></div>
<div id="details" class="details"><h3>تفاصيل العميل</h3><div id="detailsBody"></div></div>
<pre id="out">جاهز.</pre>
</div></div>
<script>
let DATA=[];
const key=()=>document.getElementById('key').value.trim();
const headers=()=>({'Content-Type':'application/json','X-Admin-Key':key()});
const body=()=>({device_id:document.getElementById('device').value.trim(),customer:document.getElementById('customer').value.trim(),duration_days:Number(document.getElementById('duration').value),ai_quota:Number(document.getElementById('quota').value||0),expires_at:document.getElementById('expires').value.trim()||null});
const out=t=>document.getElementById('out').textContent=t;
async function post(url){try{let r=await fetch(url,{method:'POST',headers:headers(),body:JSON.stringify(body())});let t=await r.text();out(t);if(r.ok)listAll()}catch(e){out('خطأ اتصال: '+e)}}
function activate(){post('/admin/activate')}function extend(){post('/admin/extend')}function updateLicense(){post('/admin/update')}function revoke(){post('/admin/revoke')}
async function listAll(){try{let r=await fetch('/admin/licenses',{headers:{'X-Admin-Key':key()}});let j=await r.json();if(!r.ok){out(JSON.stringify(j));return}DATA=j.licenses||[];render(DATA);out('تم تحديث الجدول: '+DATA.length+' عميل.')}catch(e){out('خطأ اتصال: '+e)}}
function status(x){if(x.status==='revoked')return '<span class="badge revoked">ملغى</span>';if(x.expires_at&&new Date(x.expires_at)<=new Date())return '<span class="badge expired">منتهي</span>';return '<span class="badge active">فعال</span>'}
function esc(v){return String(v??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]))}
function render(a){document.getElementById('rows').innerHTML=a.map(x=>{let pct=x.ai_quota?Math.min(100,Math.round((x.ai_used||0)/x.ai_quota*100)):0;return `<tr><td>${esc(x.customer||'—')}</td><td dir="ltr">${esc(x.device_id)}</td><td>${x.duration_days||'—'} يوم</td><td dir="ltr">${esc(x.started_at||x.created_at||'—')}</td><td dir="ltr">${esc(x.expires_at||'—')}</td><td>${status(x)}</td><td>${x.ai_used||0} / ${x.ai_quota||0} (${pct}%)</td><td dir="ltr">${esc(x.last_used_at||'—')}</td><td><button class="rowbtn secondary" onclick="loadClient('${esc(x.device_id)}')">تحميل</button><button class="rowbtn secondary" onclick="showDetails('${esc(x.device_id)}')">تفاصيل</button><button class="rowbtn danger" onclick="quickRevoke('${esc(x.device_id)}')">إلغاء</button></td></tr>`}).join('')||'<tr><td colspan="9">لا يوجد عملاء.</td></tr>'}
function filterTable(){let q=document.getElementById('search').value.toLowerCase();render(DATA.filter(x=>(x.customer||'').toLowerCase().includes(q)||(x.device_id||'').toLowerCase().includes(q)))}
function loadClient(id){let x=DATA.find(v=>v.device_id===id);if(!x)return;document.getElementById('device').value=x.device_id;document.getElementById('customer').value=x.customer||'';document.getElementById('duration').value=[7,14,30,60].includes(Number(x.duration_days))?x.duration_days:30;document.getElementById('quota').value=x.ai_quota||0;document.getElementById('expires').value=x.expires_at||'';window.scrollTo({top:0,behavior:'smooth'});out('تم تحميل بيانات العميل للتعديل.')}
async function showDetails(id){try{let r=await fetch('/admin/license/'+encodeURIComponent(id),{headers:{'X-Admin-Key':key()}});let j=await r.json();if(!r.ok){out(JSON.stringify(j));return}let e=j.events||[];document.getElementById('detailsBody').innerHTML='<b>العميل:</b> '+esc(j.customer||'—')+'<br><b>Device ID:</b> <span dir="ltr">'+esc(j.device_id)+'</span><br><b>الاشتراك:</b> '+esc(j.duration_days)+' يوم<br><b>البداية:</b> '+esc(j.started_at||'—')+'<br><b>الانتهاء:</b> '+esc(j.expires_at||'—')+'<br><b>AI:</b> '+esc(j.ai_used||0)+' / '+esc(j.ai_quota||0)+'<hr><b>سجل العمليات:</b><br>'+e.map(v=>esc(v.created_at)+' — '+esc(v.action)+' — '+esc(v.details)).join('<br>');document.getElementById('details').style.display='block'}catch(e){out('خطأ: '+e)}}
async function quickRevoke(id){document.getElementById('device').value=id;await revoke()}
</script></body></html>''')


class LicenseRequest(BaseModel):
    device_id: str
    customer: str = ""
    expires_at: str | None = None
    duration_days: int = 30
    ai_quota: int = 100000

@app.post("/admin/activate")
def admin_activate(body: LicenseRequest, request: Request):
    require_admin(request)
    device_id=body.device_id.strip()
    if not device_id: raise HTTPException(400,"Device ID مطلوب.")
    days=body.duration_days if body.duration_days in (7,14,30,60) else 30
    expires=body.expires_at.strip() if body.expires_at else _duration_expiry(days)
    from datetime import datetime, timezone
    started=datetime.now(timezone.utc).isoformat()
    quota=max(0,int(body.ai_quota))
    con=_license_db()
    try:
        con.execute("INSERT INTO licenses(device_id,customer,status,created_at,started_at,expires_at,duration_days,ai_quota,ai_used) VALUES(?,?,?,CURRENT_TIMESTAMP,?,?,?,?,0) ON CONFLICT(device_id) DO UPDATE SET customer=excluded.customer,status='active',started_at=excluded.started_at,expires_at=excluded.expires_at,duration_days=excluded.duration_days,ai_quota=excluded.ai_quota,ai_used=0",(device_id,body.customer.strip(),"active",started,expires,days,quota)); con.commit()
    finally: con.close()
    _record_license_event(device_id, "activate", f"customer={body.customer.strip()} duration_days={days} quota={quota}")
    return {"ok":True,"device_id":device_id,"status":"active","customer":body.customer.strip(),"started_at":started,"expires_at":expires,"duration_days":days,"ai_quota":quota,"ai_used":0}

@app.post("/admin/revoke")
def admin_revoke(body: LicenseRequest, request: Request):
    require_admin(request)
    con=_license_db()
    try: con.execute("UPDATE licenses SET status='revoked' WHERE device_id=?",(body.device_id.strip(),)); con.commit()
    finally: con.close()
    _record_license_event(body.device_id.strip(), "revoke", "subscription revoked")
    return {"ok":True,"device_id":body.device_id.strip(),"status":"revoked"}

@app.post("/admin/update")
def admin_update(body: LicenseRequest, request: Request):
    require_admin(request)
    device_id=body.device_id.strip()
    if not device_id: raise HTTPException(400,"Device ID مطلوب.")
    days=body.duration_days if body.duration_days in (7,14,30,60) else 30
    quota=max(0,int(body.ai_quota))
    con=_license_db()
    try:
        row=con.execute("SELECT device_id FROM licenses WHERE device_id=?",(device_id,)).fetchone()
        if not row: raise HTTPException(404,"العميل غير موجود.")
        expires=body.expires_at.strip() if body.expires_at else _duration_expiry(days)
        con.execute("UPDATE licenses SET customer=?,duration_days=?,ai_quota=?,expires_at=? WHERE device_id=?",
                    (body.customer.strip(),days,quota,expires,device_id))
        con.commit()
    finally: con.close()
    _record_license_event(device_id, "update", f"customer={body.customer.strip()} duration_days={days} quota={quota}")
    return {"ok":True,"device_id":device_id,"customer":body.customer.strip(),"duration_days":days,"ai_quota":quota,"expires_at":expires}

@app.get("/admin/license/{device_id}")
def admin_license_detail(device_id: str, request: Request):
    require_admin(request)
    item=_license_details(device_id)
    if not item: raise HTTPException(404,"العميل غير موجود.")
    return item

@app.get("/admin/events")
def admin_events(request: Request):
    require_admin(request)
    con=_license_db()
    try:
        rows=con.execute("SELECT device_id,action,details,created_at FROM license_events ORDER BY id DESC LIMIT 500").fetchall()
    finally: con.close()
    return {"events":[{"device_id":d,"action":a,"details":x,"created_at":c} for d,a,x,c in rows]}

@app.post("/admin/extend")
def admin_extend(body: LicenseRequest, request: Request):
    require_admin(request)
    device_id=body.device_id.strip(); days=body.duration_days if body.duration_days in (7,14,30,60) else 30
    from datetime import datetime,timedelta,timezone
    con=_license_db()
    try:
        row=con.execute("SELECT expires_at,duration_days FROM licenses WHERE device_id=?",(device_id,)).fetchone()
        if not row: raise HTTPException(404,"العميل غير موجود.")
        base=datetime.now(timezone.utc)
        if row[0]:
            try: base=max(base,datetime.fromisoformat(row[0].replace("Z","+00:00")))
            except Exception: pass
        exp=(base+timedelta(days=days)).isoformat()
        con.execute("UPDATE licenses SET status='active',expires_at=?,duration_days=COALESCE(duration_days,0)+? WHERE device_id=?",(exp,days,device_id)); con.commit()
    finally: con.close()
    _record_license_event(device_id, "extend", f"extended_days={days}")
    return {"ok":True,"device_id":device_id,"expires_at":exp,"extended_days":days}

@app.get("/admin/licenses")
def admin_licenses(request: Request):
    require_admin(request)
    con=_license_db()
    try: rows=con.execute("SELECT device_id,customer,status,created_at,started_at,expires_at,duration_days,ai_quota,ai_used,last_used_at FROM licenses ORDER BY created_at DESC").fetchall()
    finally: con.close()
    keys=["device_id","customer","status","created_at","started_at","expires_at","duration_days","ai_quota","ai_used","last_used_at"]
    return {"licenses":[dict(zip(keys,r)) for r in rows]}

@app.post("/analyze")
async def analyze(request: Request, file: UploadFile = File(...)):
    require_activation(request)

    data = await file.read()
    mime = file.content_type or ""
    text = extract_text(data, file.filename)

    if not text and not mime.startswith("image/"):
        raise HTTPException(
            400,
            "لم أستطع استخراج النص من هذا الملف. استخدم PDF/DOCX/PPTX أو صورة واضحة."
        )

    last_material["name"] = file.filename
    last_material["text"] = text
    last_material["mime"] = mime
    last_material["image_data"] = (
        base64.b64encode(data).decode("ascii") if mime.startswith("image/") else None
    )

    prompt = """حلّل المادة الدراسية تحليلاً شاملاً، ثم أعد النتيجة كـ JSON صالح فقط، بدون Markdown وبدون أي نص خارج JSON.
استخدم هذه المفاتيح حرفياً:
{
  "title": "اسم المادة أو الموضوع",
  "summary": "ملخص واضح",
  "difficulty": "سهل/متوسط/صعب",
  "understanding": 0,
  "high_yield": ["نقاط High-Yield"],
  "topics": ["المواضيع الرئيسية"],
  "must_memorize": ["ما يجب حفظه"],
  "must_understand": ["ما يجب فهمه"],
  "terms": [{"english":"", "arabic":"", "explanation":""}],
  "comparisons": ["مقارنات مهمة"],
  "rewrite": "A clear, organized English rewrite of the study material, preserving the original scientific meaning and important terminology.",
  "study_plan": ["خطوات مرتبة لدراسة المادة"],
  "quick_revision": ["نقاط مراجعة سريعة"],
  "questions": [{"question":"", "options":["A) ","B) ","C) ","D) "], "answer":"", "explanation":""}],
  "flashcards": [{"front":"", "back":""}]
}
اجعل understanding رقماً من 0 إلى 100 يمثل وضوح المادة واستيعاب بنيتها، وليس تشخيصاً لمستوى الطالب.
لا تضع معلومات غير موجودة في المادة إلا إذا وسمتها داخل النص بأنها "معلومة إضافية".
"""

    full_schema = {
        "type": "object", "additionalProperties": False,
        "properties": {
            "title": {"type": "string"}, "summary": {"type": "string"}, "difficulty": {"type": "string"},
            "understanding": {"type": "integer", "minimum": 0, "maximum": 100},
            "high_yield": {"type": "array", "items": {"type": "string"}},
            "topics": {"type": "array", "items": {"type": "string"}},
            "must_memorize": {"type": "array", "items": {"type": "string"}},
            "must_understand": {"type": "array", "items": {"type": "string"}},
            "terms": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"english": {"type": "string"}, "arabic": {"type": "string"}, "explanation": {"type": "string"}}, "required": ["english", "arabic", "explanation"]}},
            "comparisons": {"type": "array", "items": {"type": "string"}}, "rewrite": {"type": "string"},
            "study_plan": {"type": "array", "items": {"type": "string"}}, "quick_revision": {"type": "array", "items": {"type": "string"}},
            "questions": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"question": {"type": "string"}, "options": {"type": "array", "items": {"type": "string"}}, "answer": {"type": "string"}, "explanation": {"type": "string"}}, "required": ["question", "options", "answer", "explanation"]}},
            "flashcards": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"front": {"type": "string"}, "back": {"type": "string"}}, "required": ["front", "back"]}}
        },
        "required": ["title", "summary", "difficulty", "understanding", "high_yield", "topics", "must_memorize", "must_understand", "terms", "comparisons", "rewrite", "study_plan", "quick_revision", "questions", "flashcards"]
    }

    chunk_schema = {
        "type": "object", "additionalProperties": False,
        "properties": {
            "title": {"type": "string"}, "summary": {"type": "string"},
            "high_yield": {"type": "array", "items": {"type": "string"}},
            "topics": {"type": "array", "items": {"type": "string"}},
            "must_memorize": {"type": "array", "items": {"type": "string"}},
            "must_understand": {"type": "array", "items": {"type": "string"}},
            "terms": {"type": "array", "items": {"type": "object", "additionalProperties": False, "properties": {"english": {"type": "string"}, "arabic": {"type": "string"}, "explanation": {"type": "string"}}, "required": ["english", "arabic", "explanation"]}},
            "comparisons": {"type": "array", "items": {"type": "string"}}
        },
        "required": ["title", "summary", "high_yield", "topics", "must_memorize", "must_understand", "terms", "comparisons"]
    }

    device_id=(request.headers.get("X-Device-ID") or "").strip()
    _consume_ai(device_id,max(500,min(18000,len(text[:LARGE_FILE_CHARS])//4+5000)))

    # Small/medium files: one request, with a hard input cap that stays below the rate limit.
    if len(text) <= LARGE_FILE_CHARS:
        try:
            raw = ask_ai(prompt, text_override=text[:LARGE_FILE_CHARS], schema=full_schema, name="study_analysis", max_output_tokens=5000)
            result = json.loads(raw)
            return {"filename": file.filename, "model": MODEL, "analysis": result}
        except Exception as exc:
            if "rate_limit" in str(exc).lower() or "429" in str(exc):
                raise HTTPException(429, "تم تجاوز حد التوكنات مؤقتاً. انتظر قليلاً ثم أعد المحاولة.")
            raise HTTPException(502, f"فشل تحليل المادة: {exc}")

    # Large files: analyze sequential chunks, then synthesize the compact chunk results.
    chunks = []
    pos = 0
    while pos < len(text):
        end = min(len(text), pos + CHUNK_CHARS)
        chunks.append(text[pos:end])
        if end >= len(text):
            break
        pos = max(end - 1200, pos + 1)  # small overlap keeps definitions across boundaries

    partials = []
    for i, chunk in enumerate(chunks, 1):
        instruction = f"حلّل الجزء {i} من {len(chunks)} من المادة فقط. استخرج المعلومات المهمة الموجودة فعلياً في هذا الجزء، ولا تخترع معلومات. كن مختصراً لأن هذه نتيجة وسيطة ستُدمج لاحقاً."
        try:
            raw = ask_ai(instruction, text_override=chunk, schema=chunk_schema, name="study_chunk", max_output_tokens=2200)
            partials.append(json.loads(raw))
        except Exception as exc:
            if "rate_limit" in str(exc).lower() or "429" in str(exc):
                raise HTTPException(429, "الملف كبير جداً على حد التوكنات الحالي. أعد المحاولة بعد دقيقة.")
            raise HTTPException(502, f"فشل تحليل الجزء {i}: {exc}")
        time.sleep(1.2)

    combined = json.dumps(partials, ensure_ascii=False)
    final_instruction = """ادمج نتائج تحليل أجزاء المادة التالية في تحليل نهائي واحد. لا تضف معلومات غير موجودة في نتائج الأجزاء. احذف التكرار، وحافظ على أهم النقاط والمصطلحات، ثم أنشئ النتيجة الكاملة بالمخطط المطلوب.\n\nنتائج الأجزاء:\n""" + combined
    try:
        raw = ask_ai(final_instruction, text_override="", schema=full_schema, name="study_analysis", max_output_tokens=2600)
        result = json.loads(raw)
    except Exception as exc:
        if "rate_limit" in str(exc).lower() or "429" in str(exc):
            raise HTTPException(429, "تم تجاوز حد التوكنات مؤقتاً أثناء تجميع التحليل. أعد المحاولة بعد دقيقة.")
        raise HTTPException(502, f"فشل تجميع التحليل: {exc}")

    return {"filename": file.filename, "model": MODEL, "analysis": result}



def ask_feature(instruction: str, max_output_tokens: int = 1600) -> str:
    """Run feature requests with bounded context to reduce TPM bursts."""
    text = last_material.get("text", "")
    if not text:
        return ask_ai(instruction, max_output_tokens=max_output_tokens)

    # Rewrite/translation can be assembled from smaller sections.
    if len(text) <= 18000:
        return ask_ai(instruction, text_override=text, max_output_tokens=max_output_tokens)

    parts = []
    step = 12000
    overlap = 600
    pos = 0
    while pos < len(text):
        end = min(len(text), pos + step)
        chunk = text[pos:end]
        parts.append(ask_ai(
            instruction + f"\n\nهذا الجزء {len(parts)+1} من المادة. عالج هذا الجزء فقط وحافظ على المصطلحات المهمة.",
            text_override=chunk,
            max_output_tokens=max_output_tokens,
        ))
        if end >= len(text):
            break
        pos = max(end - overlap, pos + 1)
        time.sleep(0.8)

    return "\n\n---\n\n".join(parts)

FEATURE_PROMPTS = {
    "rewrite": """Rewrite the uploaded study material in clear professional ENGLISH as an organized study handout. Keep the scientific meaning, important details, headings, definitions, mechanisms, numbers, units, and medical/pharmaceutical terminology. Do not translate it to Arabic in this mode. Do not invent information.""",
    "translate_ar": """Translate the uploaded study material into accurate medical/pharmaceutical ARABIC. Keep the original English term beside the Arabic translation when useful. Preserve headings, definitions, mechanisms, numbers, units, and important details. Do not invent information.""",
    "study": """أنشئ خطة دراسة عملية لهذه المادة: ترتيب المواضيع، ماذا أحفظ، ماذا أفهم، ثم أسئلة ومراجعة. اجعلها مناسبة لطالب طب/صيدلة.""",
    "questions": """أنشئ أسئلة امتحانية من المادة، متنوعة بين MCQ وأسئلة فهم. اذكر الإجابة الصحيحة وسببها. لا تدّعِ أن أي سؤال مضمون في الامتحان.""",
    "flashcards": """أنشئ Flashcards تغطي التعاريف والمصطلحات والآليات والأرقام والمقارنات المهمة في المادة. كل بطاقة سؤال/مصطلح ثم جواب مختصر.""",
    "terms": """استخرج أهم المصطلحات الطبية والصيدلانية من المادة في جدول نصي: English | العربية | شرح مبسط.""",
    "revision": """أنشئ مراجعة سريعة جداً للمادة: أهم ما يجب حفظه، أهم ما يجب فهمه، الأخطاء الشائعة، ونقاط High-Yield.""",
    "progress": """قيّم بنية المادة وصعوبتها ووضوحها، ثم أعطِ خطة لتحسين الدراسة. لا تدّعي معرفة مستوى الطالب الحقيقي دون بيانات اختبار.""",
    "drug": """اعمل بطاقة تعليمية عن الدواء أو المادة الفعالة المذكورة في السؤال اعتماداً على المادة المرفوعة أولاً. اذكر: الاسم العلمي، الفئة الدوائية، آلية العمل إذا كانت موجودة، الاستعمالات العامة المذكورة، الأشكال الصيدلانية/التراكيز إن وردت، أهم التحذيرات أو الآثار الجانبية إن وردت. لا تعطِ جرعة شخصية أو وصفة علاجية. إذا لم تكن المعلومة في الملف فقل ذلك بوضوح، وأي معرفة إضافية ابدأها بعبارة "معلومة إضافية".""",
}


class FeatureRequest(BaseModel):
    feature: str
    query: str = ""

@app.post("/feature")
def feature(body: FeatureRequest, request: Request):
    require_activation(request)
    if not last_material["name"]:
        raise HTTPException(400, "ارفع المادة أولاً.")
    instruction = FEATURE_PROMPTS.get(body.feature)
    if not instruction:
        raise HTTPException(400, "الميزة غير معروفة.")
    if body.feature == "drug":
        if not body.query.strip():
            raise HTTPException(400, "اكتب اسم الدواء أو المادة الفعالة.")
        instruction += "\n\nاسم الدواء/المادة الفعالة المطلوب تحليلها: " + body.query.strip()
    device_id=(request.headers.get("X-Device-ID") or "").strip()
    _consume_ai(device_id,max(500,min(12000,len(last_material.get("text", ""))//4+1800)))
    try:
        return {"feature": body.feature, "answer": ask_feature(instruction)}
    except Exception as exc:
        msg=str(exc).lower()
        if "429" in msg or "rate_limit" in msg: raise HTTPException(429,"تم الوصول إلى حد AI مؤقتاً. انتظر ثم أعد المحاولة بملف أصغر.")
        raise HTTPException(502,f"فشل تنفيذ الميزة: {exc}")

class ChatRequest(BaseModel):
    question: str

@app.post("/chat")
def chat(body: ChatRequest, request: Request):
    require_activation(request)
    if not last_material["name"]:
        return {"answer": "ارفع مادة أولاً حتى أجيب بناءً عليها."}
    q = body.question.strip()
    if not q:
        raise HTTPException(400, "اكتب السؤال.")
    instruction = f"""أجب عن سؤال الطالب اعتماداً على المادة المرفوعة أولاً.
إذا لم تكن الإجابة موجودة في المادة، قل ذلك بوضوح. وإذا استخدمت معرفة إضافية، ابدأ فقرتها بـ "معلومة إضافية".

سؤال الطالب:
{q}
"""
    device_id=(request.headers.get("X-Device-ID") or "").strip()
    _consume_ai(device_id,max(300,min(5000,len(last_material.get("text", ""))//8+len(q)//4+700)))
    try:
        return {"answer": ask_feature(instruction,max_output_tokens=700)}
    except Exception as exc:
        msg=str(exc).lower()
        if "429" in msg or "rate_limit" in msg: raise HTTPException(429,"تم الوصول إلى حد AI مؤقتاً. انتظر ثم أعد المحاولة.")
        raise HTTPException(502,f"فشل اتصال AI: {exc}")

@app.post("/reset")
def reset():
    last_material.update({"name": None, "text": "", "image_data": None, "mime": None})
    return {"ok": True}
